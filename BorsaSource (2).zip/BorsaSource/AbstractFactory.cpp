#include <iostream>
#include <memory>

// Soyut taban sınıf
class Stock {
public:
    virtual void info() = 0;
    virtual ~Stock() = default;
};

class SiseCam : public Stock {
public:
    void info() override {
        std::cout << "SISE: Şişecam hisse senedi.\n";
    }

    static std::unique_ptr<Stock> create() {
        return std::make_unique<SiseCam>();
    }
};

int main() {
    auto sise = SiseCam::create(); // Açıklama: Sınıf kendi üretim metodunu sağlar.
    sise->info();
    return 0;
}