// Hisse.hpp
#pragma once
#include <string>
#include <memory>
#include <iostream>

// Soyut temel sınıf: Hisse
class Hisse {
public:
    virtual ~Hisse() = default;                           // Sanal yıkıcı
    virtual std::string bilgi() const = 0;                // Saf sanal fonksiyon
};

// Somut Hisse türleri
class BankaHissesi : public Hisse {
public:
    std::string bilgi() const override {
        return "Banka Hissesi: AKBNK";
    }
};

class TeknolojiHissesi : public Hisse {
public:
    std::string bilgi() const override {
        return "Teknoloji Hissesi: ASELS";
    }
};

class EnerjiHissesi : public Hisse {
public:
    std::string bilgi() const override {
        return "Enerji Hissesi: TUPRS";
    }
};

// HisseFactory.hpp
#pragma once
#include "Hisse.hpp"
#include <string_view>
#include <stdexcept>
#include <unordered_map>
#include <functional>

// Genişletilebilir factory sistemi
class HisseFactory {
    using Creator = std::function<std::unique_ptr<Hisse>()>;
    std::unordered_map<std::string, Creator> kayitlar;
public:
    void kaydet(const std::string& ad, Creator c) {
        kayitlar[ad] = std::move(c);
    }

    std::unique_ptr<Hisse> create(const std::string& sektor) const {
        auto it = kayitlar.find(sektor);
        if (it != kayitlar.end())
            return (it->second)();
        throw std::invalid_argument("Bilinmeyen sektör: " + sektor);
    }
};

// main.cpp
#include "HisseFactory.hpp"

int main() {
    HisseFactory factory; // 1️⃣ Genişletilebilir factory oluşturuluyor

    // 2️⃣ Kayıtlar yapılır
    factory.kaydet("banka", [] { return std::make_unique<BankaHissesi>(); });
    factory.kaydet("teknoloji", [] { return std::make_unique<TeknolojiHissesi>(); });
    factory.kaydet("enerji", [] { return std::make_unique<EnerjiHissesi>(); });

    // 3️⃣ Kullanım
    auto h1 = factory.create("banka");
    auto h2 = factory.create("teknoloji");

    std::cout << h1->bilgi() << '\n';
    std::cout << h2->bilgi() << '\n';

    return 0;
}