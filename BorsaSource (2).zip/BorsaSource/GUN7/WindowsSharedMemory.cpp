#include <iostream>
#include <unordered_map>
#include <string>
#include <windows.h>
#include <cstring>     // memcpy için
#include <sstream>     // string çözümleme

// 🔧 Sabitler
const char* SHM_NAME = "HisseFiyatlari"; // Windows shared memory adı
const size_t SHM_SIZE = 1024;                    // Bellek boyutu (1 KB)

void producer() {
    // Hisse fiyatlarını map içinde tut
    std::unordered_map<std::string, double> fiyatlar = {
        {"AKBNK", 37.5},
        {"SISE", 52.3},
        {"FROTO", 1020.1},
        {"THYAO", 310.7}
    };

    // String'e dönüştür (örnek: "AKBNK=37.5;SISE=52.3;...")
    std::ostringstream oss;
    for (const auto& [k, v] : fiyatlar) {
        oss << k << '=' << v << ';';
    }
    std::string serialized = oss.str();

    // Shared memory oluştur
    HANDLE hMapFile = CreateFileMappingA(
        INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE,
        0, SHM_SIZE, SHM_NAME);

    if (!hMapFile) {
        std::cerr << "Shared memory oluşturulamadı\n";
        return;
    }

    // Belleği eşle
    void* pBuf = MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, SHM_SIZE);
    if (!pBuf) {
        std::cerr << "MapViewOfFile başarısız\n";
        CloseHandle(hMapFile);
        return;
    }

    // Veriyi kopyala
    std::memcpy(pBuf, serialized.c_str(), serialized.size() + 1);
    std::cout << "[PRODUCER] Shared memory'e yazıldı: \n" << serialized << "\n";

    // Temizle
    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);
}

void consumer() {
    // Shared memory'e bağlan
    HANDLE hMapFile = OpenFileMappingA(FILE_MAP_READ, FALSE, SHM_NAME);
    if (!hMapFile) {
        std::cerr << "Shared memory'e bağlanılamadı (önce producer çalışmalı)\n";
        return;
    }

    // Belleği eşle
    void* pBuf = MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, SHM_SIZE);
    if (!pBuf) {
        std::cerr << "MapViewOfFile başarısız\n";
        CloseHandle(hMapFile);
        return;
    }

    // Veriyi oku ve çöz
    const char* raw = static_cast<const char*>(pBuf);
    std::unordered_map<std::string, double> fiyatlar;
    std::istringstream iss(raw);
    std::string pair;

    while (std::getline(iss, pair, ';')) {
        auto eq = pair.find('=');
        if (eq != std::string::npos) {
            std::string kod = pair.substr(0, eq);
            double fiyat = std::stod(pair.substr(eq + 1));
            fiyatlar[kod] = fiyat;
        }
    }

    // Yazdır
    std::cout << "[CONSUMER] Shared memory'den okunan fiyatlar:\n";
    for (const auto& [k, v] : fiyatlar)
        std::cout << k << " = " << v << " TL\n";

    // Temizle
    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);
}

int main(int argc, char* argv[]) {
    if (argc > 1 && std::string(argv[1]) == "read") {
        consumer(); // Okuma
    } else {
        producer(); // Yazma
    }

    std::cout << "\n📌 unordered_map: süreç içinde hızlı erişim\n";
    std::cout << "📌 shared memory: process'ler arası iletişim için gereklidir\n";
    return 0;
}