#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>

// 1️⃣ Temel Fonksiyon Şablonu
template <typename T>
T maxFiyat(T a, T b) {
    return (a > b) ? a : b;
}

// 2️⃣ Şablonlu Sınıf + Şablon Fonksiyon
template <typename T>
class Donusturucu {
    T deger;
public:
    Donusturucu(T d) : deger(d) {}

    template <typename U>
    U donustur() const {
        return static_cast<U>(deger);
    }
};

// 3️⃣ Overload edilmiş fonksiyon şablonu
template <typename T>
void yazdir(const std::vector<T>& v) {
    std::cout << "Genel yazdır (vektör):\n";
    for (const T& item : v)
        std::cout << "  " << item << "\n";
}

void yazdir(const std::string& s) {
    std::cout << "Yazı: " << s << "\n";
}

// 4️⃣ Varsayılan tipli şablon fonksiyonu
template <typename T = int>
T getDefaultLot() {
    return 100; // lot birimi
}

// 5️⃣ Non-type parametreli şablon fonksiyonu
template <int sabitAdet>
void sabitIslem(const std::string& kod) {
    std::cout << kod << " için otomatik " << sabitAdet << " adetlik işlem yapıldı.\n";
}

// 👨‍💻 Ana sınıf: Hisse
class Hisse {
    std::string kod;
    double fiyat;
public:
    Hisse(std::string k, double f) : kod(k), fiyat(f) {}
    double getFiyat() const { return fiyat; }
    std::string getKod() const { return kod; }

    void yaz() const {
        std::cout << std::fixed << std::setprecision(2);
        std::cout << kod << ": " << fiyat << " TL\n";
    }
};

int main() {
    std::cout << "📈 Fonksiyon Şablonu ile Hisse Senedi Örneği\n\n";

    Hisse h1("AKBNK", 37.5);
    Hisse h2("SISE", 52.3);
    h1.yaz();
    h2.yaz();

    std::cout << "\n1️⃣ maxFiyat<T>() kullanımı:\n";
    std::cout << "En yüksek fiyat: " << maxFiyat(h1.getFiyat(), h2.getFiyat()) << " TL\n";

    std::cout << "\n2️⃣ Donusturucu<T>::donustur<U>() kullanımı:\n";
    Donusturucu<double> d(h1.getFiyat());
    int yuvarlanmis = d.donustur<int>();
    std::cout << h1.getKod() << " fiyatı yuvarlanmış: " << yuvarlanmis << "\n";

    std::cout << "\n3️⃣ Overloaded yazdir():\n";
    yazdir("Fiyatlar Listesi");
    std::vector<std::string> kodlar = { "AKBNK", "SISE", "FROTO" };
    yazdir(kodlar);

    std::cout << "\n4️⃣ Varsayılan şablon tipi:\n";
    auto lot = getDefaultLot<>(); // T = int (default)
    std::cout << "Varsayılan lot miktarı: " << lot << "\n";

    std::cout << "\n5️⃣ Non-type parametreli fonksiyon şablonu:\n";
    sabitIslem<250>("THYAO");

    return 0;
}
