#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <sstream>

// 🧱 1. Temel Sınıf Şablonu
template <typename T>
class Hisse {
protected:
    std::string kod;
    T fiyat;
public:
    Hisse(std::string k, T f) : kod(k), fiyat(f) {}
    virtual void yazdir() const {
        std::cout << kod << ": " << fiyat << " TL\n";
    }
    virtual ~Hisse() {}
};

// 🎯 2. Özelleştirilmiş Versiyon: string fiyat olursa
template <>
class Hisse<std::string> {
    std::string kod, fiyat;
public:
    Hisse(std::string k, std::string f) : kod(k), fiyat(f) {}
    void yazdir() const {
        std::cout << kod << " fiyatı string olarak girildi: " << fiyat << "\n";
    }
};

// 🧮 3. Şablonlu Kalıtım (Template Inheritance)
template <typename T>
class DetayliHisse : public Hisse<T> {
public:
    std::unordered_map<std::string, std::pair<int, int>> kurumIslemleri;
    DetayliHisse(std::string k, T f) : Hisse<T>(k, f) {}

    void islemEkle(const std::string& kurum, int alim, int satim) {
        kurumIslemleri[kurum] = {alim, satim};
    }

    void yazdir() const override {
        this->Hisse<T>::yazdir();
        for (const auto& [kurum, islem] : kurumIslemleri) {
            std::cout << "  " << kurum << ": +" << islem.first << " / -" << islem.second << "\n";
        }
    }
};

// 🧊 4. Non-Type Parametre: Sabit kapasite
template <typename T, int MAX>
class EmirDefteri {
    std::vector<T> emirler;
public:
    void ekle(T emir) {
        if (emirler.size() < MAX)
            emirler.push_back(emir);
        else
            std::cout << "Emir defteri dolu!\n";
    }
    void yaz() {
        std::cout << emirler.size() << " emir kayıtlı.\n";
    }
};

// 🧩 5. Template-template parametresi
template <template <typename> class Koleksiyon>
class Sarmal {
    Koleksiyon<std::string> kodlar;
public:
    void dummy() { std::cout << "Sarmal konteyner aktif.\n"; }
};

// ⚙️ 6. Varsayılan Tipli Şablon
template <typename T = double>
class FiyatTutucu {
    T fiyat;
public:
    FiyatTutucu(T f) : fiyat(f) {}
    void goster() { std::cout << "Fiyat: " << fiyat << "\n"; }
};

// 🧠 7. Şablonlu Üye Fonksiyon
template <typename T>
class Donusturucu {
    T deger;
public:
    Donusturucu(T d) : deger(d) {}
    template <typename U>
    U cevir() {
        return static_cast<U>(deger);
    }
};

// 🔄 8. İç içe Şablon Sınıf
template <typename T>
class Kayit {
public:
    template <typename U>
    class Alt {
        T x;
        U y;
    public:
        Alt(T a, U b) : x(a), y(b) {}
        void yaz() {
            std::cout << "Alt kayıt: " << x << " ve " << y << "\n";
        }
    };
};

int main() {
    std::cout << "\n🎯 Detaylı Hisse Örneği:\n";
    DetayliHisse<double> akbank("AKBNK", 37.5);
    akbank.islemEkle("Ziraat", 5000, 3000);
    akbank.islemEkle("Garanti", 1200, 4000);
    akbank.yazdir();

    std::cout << "\n🧮 Sabit Boyutlu Emir Defteri:\n";
    EmirDefteri<std::string, 3> defter;
    defter.ekle("AKBNK Al 1000");
    defter.ekle("SISE Sat 500");
    defter.ekle("FROTO Al 200");
    defter.ekle("EKSTRA Sat 50");  // dolu
    defter.yaz();

    std::cout << "\n🔁 Donuşturucu Şablonu:\n";
    Donusturucu<int> d(100);
    double c = d.cevir<double>();
    std::cout << "int → double: " << c << "\n";

    std::cout << "\n📦 Varsayılan Tipli Fiyat:\n";
    FiyatTutucu<> f1(45.3);     // double varsayılan
    f1.goster();

    std::cout << "\n🔧 İç içe şablon örneği:\n";
    Kayit<std::string>::Alt<int> kayit("AKBNK", 5000);
    kayit.yaz();

    std::cout << "\n🧩 Template-template örneği:\n";
    Sarmal<std::vector> s;
    s.dummy();

    std::cout << "\n🧪 Tam Özelleştirme örneği:\n";
    Hisse<std::string> h2("SISE", "52.3 TL");
    h2.yazdir();

    return 0;
}
