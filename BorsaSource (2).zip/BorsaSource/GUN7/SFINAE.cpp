#include <iostream>
#include <string>
#include <vector>
#include <type_traits>
#include <concepts>

// 🎯 Sadece aritmetik (int, float, double...) fiyatlara izin verilen şablon
template<typename T>
std::enable_if_t<std::is_arithmetic_v<T>, T>
addPrice(T price1, T price2) {
    return price1 + price2;
}

// 🧠 Concept: sadece STL benzeri kapsayıcılar için geçerli
template<typename T>
concept StockContainer = requires(T t) {
    { t.size() } -> std::convertible_to<std::size_t>;  // size() dönüşümlerine izin ver
    t.begin();  // begin() fonksiyonu olmalı
    t.end();    // end() fonksiyonu olmalı
};

// 🖨️ Concept kullanan bir fonksiyon: hisse kodlarını yazdırır
template<StockContainer C>
void yazdirKodlar(const C& container) {
    std::cout << "📦 Kodlar:\n";
    for (const auto& item : container) {
        std::cout << "  " << item << '\n';
    }
}

int main() {
    // ✔ Geçerli: double fiyatlar
    double akbankPrice = 36.5;
    double garantiPrice = 49.8;

    double total = addPrice(akbankPrice, garantiPrice);
    std::cout << "Toplam fiyat: " << total << " TL\n";

    // ✔ Geçerli: int fiyatlar
    int kapanis1 = 30;
    int kapanis2 = 40;
    std::cout << "Toplam kapanış: " << addPrice(kapanis1, kapanis2) << " TL\n";

    // ❌ Geçersiz: string fiyat (aşağıdaki satır derlenmez)
    // std::cout << addPrice(std::string("36.5"), std::string("49.8")) << "\n";

    // 🧪 Concept kullanılan örnek
    std::vector<std::string> kodlar = { "AKBNK", "SISE", "FROTO" };
    // yazdirKodlar(kodlar);  // ✅ vector concept'i sağlıyor
    for (const auto& k : kodlar) std::cout << k << "\n";

    // ❌ Concept ihlali (örnek için yorumlu)
    // int dizi[3] = {1, 2, 3};
    // yazdirKodlar(dizi);  // Hatalı çünkü array'ler size() metoduna sahip değil

    return 0;
}

