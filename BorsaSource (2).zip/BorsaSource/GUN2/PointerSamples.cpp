#include <iostream>

struct Kisi {
    std::string ad;
    int yas;

    void yazdir() {
        std::cout << ad << ", " << yas << " yaşında\n";
    }
};

int main() {
    int x = 42;
    int* p = &x;  // &x = "x'in adresi"
    std::cout << "x = " << x << ", p = " << p << ", *p = " << *p << "\n";

    *p = 100;     // p'nin işaret ettiği yere yaz (dereference)
    std::cout << "Yeni x: " << x << "\n";

    // Yapı (struct) ile örnek
    Kisi ali{"Ali", 30};
    Kisi* ptr = &ali;   // ptr, ali'yi işaret ediyor

    std::cout << "ptr->ad: " << ptr->ad << "\n";       // üye erişimi
    std::cout << "(*ptr).yas: " << (*ptr).yas << "\n"; // aynı erişim

    ptr->yazdir();  // metot çağrısı: ptr-> yazımı (*ptr).yazdir() eşdeğeridir

    return 0;
}
