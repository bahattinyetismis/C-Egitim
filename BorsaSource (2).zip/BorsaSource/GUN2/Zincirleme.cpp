#include <iostream>
#include <string>

struct PencereAyar {
    int gen = 800;
    int yuk = 600;
    bool tamEkran = false;
    std::string baslik = "Varsayılan Pencere";

    // Zincirleme metotlar
    PencereAyar& setGen(int g) {
        gen = g;
        return *this;
    }

    PencereAyar& setYuk(int y) {
        yuk = y;
        return *this;
    }

    PencereAyar& setTamEkran(bool t) {
        tamEkran = t;
        return *this;
    }

    PencereAyar& setBaslik(const std::string& b) {
        baslik = b;
        return *this;
    }
};

// Pencereyi oluşturan fonksiyon (simülasyon)
void olustur(const PencereAyar& ayar) {
    std::cout << "Pencere Oluşturuluyor:\n";
    std::cout << "Başlık    : " << ayar.baslik << "\n";
    std::cout << "Boyut     : " << ayar.gen << "x" << ayar.yuk << "\n";
    std::cout << "Tam Ekran : " << (ayar.tamEkran ? "Evet" : "Hayır") << "\n";
}

int main() {
    // Builder Pattern kullanarak ayar yap
    auto ayar = PencereAyar{}
                    .setGen(1024)
                    .setYuk(768)
                    .setTamEkran(true)
                    .setBaslik("Uygulama Penceresi");

    // Pencereyi oluştur
    olustur(ayar);

    return 0;
}
