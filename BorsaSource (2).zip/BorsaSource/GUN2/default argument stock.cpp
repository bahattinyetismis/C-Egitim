#include <iostream>
#include <string>

// Sabit KDV oranı tanımla
constexpr double DEFAULT_KDV = 0.20;

struct Stock {
    std::string kod;
    double fiyat;
    double kdv = DEFAULT_KDV;  // Varsayılan KDV oranı

    // Constructor ekle
    Stock(const std::string& k, double f) : kod(k), fiyat(f) {}
};

void guncelle(Stock& s, double yeniFiyat, double kdv = DEFAULT_KDV) {
    s.fiyat = yeniFiyat * (1.0 + kdv);
}

int main() {
    Stock s("ASELS", 50.0);  // Normal constructor kullanımı
    guncelle(s, 55.0);       // KDV varsayılan
    std::cout << s.kod << " yeni: " << s.fiyat << '\n';
}
