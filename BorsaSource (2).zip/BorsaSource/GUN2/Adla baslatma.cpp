#include <iostream>
#include <string>

struct PencereAyar {
    int   gen  = 800;
    int   yuk  = 600;
    bool  tamEkran = false;
};

// Simülasyon: pencere oluşturur
void olustur(const PencereAyar& ayar) {
    std::cout << "Pencere Oluşturuluyor:\n";
    std::cout << "Genişlik   : " << ayar.gen << "\n";
    std::cout << "Yükseklik  : " << ayar.yuk << "\n";
    std::cout << "Tam Ekran  : " << (ayar.tamEkran ? "Evet" : "Hayır") << "\n";
}

int main() {
    // Varsayılan değerlerden sadece bazılarını değiştir
    olustur({ .yuk = 720, .tamEkran = true });

    // Tüm değerleri belirle
    PencereAyar tam = { .gen = 1280, .yuk = 1024, .tamEkran = false };
    olustur(tam);

    // Hiçbir şey verilmezse, tümü varsayılan
    PencereAyar varsayilan;
    olustur(varsayilan);

    return 0;
}
