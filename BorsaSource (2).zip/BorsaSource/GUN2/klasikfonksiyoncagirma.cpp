#include <iostream>
#include <string>

struct PencereAyar {
    int gen;
    int yuk;
    bool tamEkran;

    // Constructor: tüm alanlar için varsayılanlar içerir
    PencereAyar(int g = 800, int y = 600, bool t = false)
        : gen(g), yuk(y), tamEkran(t) {}
};

// Pencere oluşturucu fonksiyon
void olustur(const PencereAyar& ayar) {
    std::cout << "Pencere Oluşturuluyor:\n";
    std::cout << "Genişlik   : " << ayar.gen << "\n";
    std::cout << "Yükseklik  : " << ayar.yuk << "\n";
    std::cout << "Tam Ekran  : " << (ayar.tamEkran ? "Evet" : "Hayır") << "\n\n";
}

int main() {
    // 1. Tümü varsayılan
    PencereAyar ayar1;
    olustur(ayar1);

    // 2. Sadece genişlik verildi
    PencereAyar ayar2(1024); // gen = 1024, yuk = 600, tamEkran = false
    olustur(ayar2);

    // 3. Genişlik ve yükseklik verildi
    PencereAyar ayar3(1280, 720); // tamEkran = false (varsayılan)
    olustur(ayar3);

    // 4. Hepsi verildi
    PencereAyar ayar4(1920, 1080, true);
    olustur(ayar4);

    return 0;
}
