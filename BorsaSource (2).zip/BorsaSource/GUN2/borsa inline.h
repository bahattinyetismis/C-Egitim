#ifndef BORSA_H
#define BORSA_H

// Hisse başına kar/zarar hesaplayan inline fonksiyon
inline double hisseKarZarar(double alis, double satis) {
    return satis - alis;
}

// Toplam kar/zarar hesaplayan inline fonksiyon
inline double toplamKarZarar(double alis, double satis, int adet) {
    return (satis - alis) * adet;
}

#endif
