#include <iostream>
#include <string>
#include <fstream>
using namespace std;

// Define pi constant
constexpr double PI = 3.14159265358979323846;

// Function declarations with default arguments
void yaz(string mesaj, char ayirac = '\n');
void bildir(string mesaj);
void bildir(string mesaj, ostream& out);
void log(string mesaj, bool zamanli = true);
template<typename T>
void yazT(const T& veri, char son = '\n');
double alan(double r, double pi = PI);

// Function definitions
void yaz(string mesaj, char ayirac) {
    cout << "[YAZ] " << mesaj << ayirac;
}

void bildir(string mesaj) {
    cout << "[STDOUT] " << mesaj << '\n';
}

void bildir(string mesaj, ostream& out) {
    out << "[DOSYA] " << mesaj << '\n';
}

void log(string mesaj, bool zamanli) {
    if (zamanli)
        cout << "[LOG-ZAMANLI] " << mesaj << '\n';
    else
        cout << "[LOG] " << mesaj << '\n';
}

template<typename T>
void yazT(const T& veri, char son) {
    cout << "[TEMPLATE] " << veri << son;
}

double alan(double r, double pi) {
    return pi * r * r;
}

// Class declarations
class Rapor {
public:
    void yaz(string baslik, bool renkli = true);
};

struct Base {
    virtual void yaz(string msg, bool buyuk = false);
};

struct Turemis : Base {
    void yaz(string msg, bool buyuk) override;
};

// Class method definitions
void Rapor::yaz(string baslik, bool renkli) {
    if (renkli)
        cout << "[RENKLI RAPOR] " << baslik << '\n';
    else
        cout << "[S/B RAPOR] " << baslik << '\n';
}

void Base::yaz(string msg, bool buyuk) {
    cout << (buyuk ? "[BUYUK] " : "[NORMAL] ") << msg << '\n';
}

void Turemis::yaz(string msg, bool buyuk) {
    cout << "[TURETILMIS] " << (buyuk ? "[BUYUK] " : "[NORMAL] ") << msg << '\n';
}

int main() {
    cout << "1. Default Parametre:\n";
    yaz("Merhaba");
    yaz("Selam", '!');

    cout << "\n2. Overload:\n";
    ofstream dosya("cikti.txt");
    bildir("Ekrana yaz");
    bildir("Dosyaya yaz", dosya);
    dosya.close();

    cout << "\n3. Default Argument (cakisimsiz):\n";
    log("Zamanli mesaj");
    log("Zamansiz mesaj", false);

    cout << "\n4. Template Default:\n";
    yazT(42);
    yazT("Merhaba", '!');

    cout << "\n5. Constexpr ile Default:\n";
    cout << "Alan (r=2): " << alan(2.0) << '\n';

    cout << "\n6. Sinif Fonksiyonu Default:\n";
    Rapor r;
    r.yaz("Performans Raporu");
    r.yaz("Yedek Rapor", false);

    cout << "\n7. Sanal Fonksiyon Default:\n";
    Base* p = new Turemis();
    p->yaz("Mesaj");
    p->yaz("Zorunlu buyuk", true);
    delete p;

    return 0;
}
