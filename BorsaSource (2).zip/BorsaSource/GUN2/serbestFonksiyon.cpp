#include <iostream>
#include <vector>
#include <string>

class Stock {
public:
    std::string symbol;
    std::string name;
    double price;
    int volume;

    Stock(const std::string& sym, const std::string& nm, double prc, int vol)
        : symbol(sym), name(nm), price(prc), volume(vol) {}
};

inline void guncelle(Stock& s, double yeniFiyat) {
    s.price = yeniFiyat;
}

int main()
{
    std::vector<Stock> portfoy {
        {"AKBNK", "Akbank",        32.10, 5000000},
        {"ASELS", "Aselsan",       57.25, 3200000}
    };

    // 1) tüm hisseleri %2 indirimli kapat
    for (auto& s : portfoy) {                  // & -> referans
        guncelle(s, s.price * 0.98);
    }

    // 2) ekran çıktısı
    for (const auto& s : portfoy) {
        std::cout << s.symbol << " yeni fiyat: " << s.price << '\n';
    }
}
