#include <array>
#include <iostream>
#include <chrono>

// Derleme zamanında hesaplanan küp tablosu (constexpr)
constexpr std::array<long long, 10000> cubeTableConstexpr() {
    std::array<long long, 10000> a{};
    for (int i = 0; i < 10000; ++i)
        a[i] = 1LL * i * i * i;
    return a;
}

// Çalışma zamanında hesaplanan küp tablosu
std::array<long long, 10000> cubeTableRuntime() {
    std::array<long long, 10000> a{};
    for (int i = 0; i < 10000; ++i)
        a[i] = 1LL * i * i * i;
    return a;
}

constexpr auto tablo1 = cubeTableConstexpr();

int main() {
    // constexpr tablo derleme sırasında oluştuğu için burada süre sıfırdır

    // runtime tablo: süreyi ölçelim
    auto basla = std::chrono::high_resolution_clock::now();
    auto tablo2 = cubeTableRuntime();
    auto bitis = std::chrono::high_resolution_clock::now();

    // kontrol amaçlı bir eleman yazdır
    std::cout << "tablo2[9999] = " << tablo2[9999] << "\n";

    auto sure = std::chrono::duration<double, std::micro>(bitis - basla).count();
    std::cout << "Runtime fonksiyon süresi: " << sure << " mikro saniye\n";

    return 0;
}
