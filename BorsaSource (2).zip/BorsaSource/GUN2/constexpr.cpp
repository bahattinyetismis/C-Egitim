#include <iostream>

constexpr bool asal(int n) {
    if (n <= 1) return false;
    for (int i = 2; i*i <= n; ++i)
        if (n % i == 0) return false;
    return true;
}

int main() {
    static_assert(asal(97), "97 asal sayı değil!");  // derleme zamanında kontrol
    int x;
    std::cout << "Bir sayı giriniz: ";
    std::cin >> x;
    std::cout << (asal(x) ? "Asal" : "Asal değil") << std::endl;
    return 0;
}
