#include <iostream>
#include "borsa inline.h"

int main() {
    double alisFiyati = 22.75;
    double satisFiyati = 25.10;
    int adet = 150;

    std::cout << "Hisse başına kâr: " << hisseKarZarar(alisFiyati, satisFiyati) << " TL" << std::endl;
    std::cout << "Toplam kâr: " << toplamKarZarar(alisFiyati, satisFiyati, adet) << " TL" << std::endl;

    return 0;
}
