#include <iostream>

int main() {
    constexpr auto cube = [](int x){ return x * x * x; };

    static_assert(cube(4) == 64, "Hata: 4'ün küpü 64 değil!");  // derleme zamanı kontrol

    int n;
    std::cout << "Bir sayı girin: ";
    std::cin >> n;

    std::cout << n << " sayısının küpü: " << cube(n) << std::endl;

    return 0;
}
