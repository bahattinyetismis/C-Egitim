// Bu dosya, template'lerle yazılmış Hisse uygulamasının derleyici tarafından instantiation sonrası oluşan HALİDİR.
// Tüm template parametreleri yerine konmuş, her tür için ayrı sınıf oluşturulmuştur.

#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <sstream>

// 1️⃣ Hisse<double>
class Hisse_double {
protected:
    std::string kod;
    double fiyat;
public:
    Hisse_double(std::string k, double f) : kod(k), fiyat(f) {}
    virtual void yazdir() const {
        std::cout << kod << ": " << fiyat << " TL\n";
    }
    virtual ~Hisse_double() {}
};

// 2️⃣ Hisse<std::string> (tam özelleştirme)
class Hisse_string {
    std::string kod, fiyat;
public:
    Hisse_string(std::string k, std::string f) : kod(k), fiyat(f) {}
    void yazdir() const {
        std::cout << kod << " fiyatı string olarak girildi: " << fiyat << "\n";
    }
};

// 3️⃣ DetayliHisse<double>
class DetayliHisse_double : public Hisse_double {
public:
    std::unordered_map<std::string, std::pair<int, int>> kurumIslemleri;
    DetayliHisse_double(std::string k, double f) : Hisse_double(k, f) {}

    void islemEkle(const std::string& kurum, int alim, int satim) {
        kurumIslemleri[kurum] = {alim, satim};
    }

    void yazdir() const override {
        Hisse_double::yazdir();
        for (const auto& [kurum, islem] : kurumIslemleri) {
            std::cout << "  " << kurum << ": +" << islem.first << " / -" << islem.second << "\n";
        }
    }
};

// 4️⃣ EmirDefteri<std::string, 3>
class EmirDefteri_string_3 {
    std::vector<std::string> emirler;
public:
    void ekle(std::string emir) {
        if (emirler.size() < 3)
            emirler.push_back(emir);
        else
            std::cout << "Emir defteri dolu!\n";
    }
    void yaz() {
        std::cout << emirler.size() << " emir kayıtlı.\n";
    }
};

// 5️⃣ Sarmal<std::vector>
class Sarmal_vector {
    std::vector<std::string> kodlar;
public:
    void dummy() { std::cout << "Sarmal konteyner aktif.\n"; }
};

// 6️⃣ FiyatTutucu<double>
class FiyatTutucu_double {
    double fiyat;
public:
    FiyatTutucu_double(double f) : fiyat(f) {}
    void goster() { std::cout << "Fiyat: " << fiyat << "\n"; }
};

// 7️⃣ Donusturucu<int>
class Donusturucu_int {
    int deger;
public:
    Donusturucu_int(int d) : deger(d) {}

    template <typename U>
    U cevir() {
        return static_cast<U>(deger);
    }
};

// 8️⃣ Kayit<std::string>::Alt<int>
class Kayit_string_Alt_int {
    std::string x;
    int y;
public:
    Kayit_string_Alt_int(std::string a, int b) : x(a), y(b) {}
    void yaz() {
        std::cout << "Alt kayıt: " << x << " ve " << y << "\n";
    }
};

int main() {
    std::cout << "\n🎯 Detaylı Hisse Örneği:\n";
    DetayliHisse_double akbank("AKBNK", 37.5);
    akbank.islemEkle("Ziraat", 5000, 3000);
    akbank.islemEkle("Garanti", 1200, 4000);
    akbank.yazdir();

    std::cout << "\n🧮 Sabit Boyutlu Emir Defteri:\n";
    EmirDefteri_string_3 defter;
    defter.ekle("AKBNK Al 1000");
    defter.ekle("SISE Sat 500");
    defter.ekle("FROTO Al 200");
    defter.ekle("EKSTRA Sat 50");
    defter.yaz();

    std::cout << "\n🔁 Donuşturucu Şablonu:\n";
    Donusturucu_int d(100);
    double c = d.cevir<double>();
    std::cout << "int → double: " << c << "\n";

    std::cout << "\n📦 Varsayılan Tipli Fiyat:\n";
    FiyatTutucu_double f1(45.3);
    f1.goster();

    std::cout << "\n🔧 İç içe şablon örneği:\n";
    Kayit_string_Alt_int kayit("AKBNK", 5000);
    kayit.yaz();

    std::cout << "\n🧩 Template-template örneği:\n";
    Sarmal_vector s;
    s.dummy();

    std::cout << "\n🧪 Tam Özelleştirme örneği:\n";
    Hisse_string h2("SISE", "52.3 TL");
    h2.yazdir();

    return 0;
}