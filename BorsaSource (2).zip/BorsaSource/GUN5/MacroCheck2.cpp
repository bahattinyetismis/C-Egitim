#include <iostream>

#define DECL_COUNTER(name) int counter_##name = 0
#define INCR_COUNTER(name) counter_##name++

int main() {
    DECL_COUNTER(test);         // should become: int counter_test = 0;
    INCR_COUNTER(test);         // should become: counter_test++;

    std::cout << "Counter value: " << counter_test << std::endl;
    return 0;
}