#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

// Hisse senedi sınıfı
class Stock {
    std::string symbol_;
    double price_;
    int lot_;

public:
    Stock(std::string symbol, double price, int lot)
        : symbol_(std::move(symbol)), price_(price), lot_(lot) {}

    double price() const { return price_; }
    int lot() const { return lot_; }
    const std::string& symbol() const { return symbol_; }

    void print() const {
        std::cout << symbol_ << " (" << lot_ << " lot) @ " << price_ << " TL\n";
    }
};

int main() {
    // Portföydeki hisseler
    std::vector<Stock> portfolio{
        {"ASELS", 87.5, 100},
        {"THYAO", 315.0, 50},
        {"KRDMD", 42.1, 200},
        {"SISE", 55.3, 150},
        {"FROTO", 1230.0, 10}
    };

    // 1. Fiyatı 100 TL'den büyük olanları filtrele (lambda ile)
    std::vector<Stock> expensive;
    std::copy_if(portfolio.begin(), portfolio.end(), std::back_inserter(expensive),
        [](const Stock& s) { return s.price() > 100.0; });

    std::cout << "Fiyati 100 TL'den buyuk olanlar:\n";
    std::for_each(expensive.begin(), expensive.end(),
        [](const Stock& s) { s.print(); });

    // 2. Lot sayısına göre azalan sırala (lambda ile)
    std::sort(portfolio.begin(), portfolio.end(),
        [](const Stock& a, const Stock& b) { return a.lot() > b.lot(); });

    std::cout << "\nPortfoy lot sayisina gore azalan sirali:\n";
    for (const auto& s : portfolio)
        s.print();

    // 3. Sadece belirli bir sembolü bul (lambda ve std::find_if ile)
    auto it = std::find_if(portfolio.begin(), portfolio.end(),
        [](const Stock& s) { return s.symbol() == "SISE"; });

    if (it != portfolio.end()) {
        std::cout << "\nSISE bulundu: ";
        it->print();
    } else {
        std::cout << "\nSISE portföyde yok.\n";
    }
}