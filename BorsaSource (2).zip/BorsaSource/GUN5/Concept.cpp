#include <iostream>
#include <string>
#include <vector>
#include <concepts>   // C++20 concept tanımları
#include <cstddef>    // std::size_t

// 📦 Hisse senedi veri yapısı
struct Stock {
    std::string symbol;
    double price;
};

// 🧠 Concept: yalnızca tamsayı türler için geçerli
template<std::integral T>
T addShares(T a, T b) {
    return a + b;
}

// 🧠 Concept: Container — size() döndüren, begin()/end() olan türler
template<typename T>
concept StockContainer = requires(T t) {
    { t.size() } -> std::same_as<std::size_t>;  // size() -> std::size_t
    t.begin(); t.end();                         // iterable olmalı
};

// ✨ Bu fonksiyon yalnızca Container olan türler için geçerli
template<StockContainer C>
void printStockList(const C& stocks) {
    std::cout << "Portföy (" << stocks.size() << " hisse):\n";
    for (const auto& s : stocks) {
        std::cout << " - " << s.symbol << " (" << s.price << " TL)\n";
    }
}

int main() {
    // ✔ Concept: integral → geçerli
    int a = 100, b = 50;
    std::cout << "Toplam lot: " << addShares(a, b) << "\n";

    // ❌ Concept dışında: double → derlenmez (çünkü integral değil)
    // double x = 1.2, y = 3.4;
    // std::cout << addShares(x, y); // GEÇERSİZ

    // ✔ Concept: Container → std::vector<Stock> geçerli
    std::vector<Stock> portfoy = {
        {"AKBNK", 36.5},
        {"GARAN", 49.8},
        {"SISE", 52.3}
    };
    printStockList(portfoy);

    return 0;
}
