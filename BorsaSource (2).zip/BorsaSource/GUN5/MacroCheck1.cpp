#include <iostream>

int main() {
    int counter_apples = 0;
    int counter_oranges = 0;
    int counter_pears = 0;

    counter_apples++;
    counter_oranges += 2;
    counter_pears += 3;

    std::cout << "Apples: " << counter_apples << std::endl;
    std::cout << "Oranges: " << counter_oranges << std::endl;
    std::cout << "Pears: " << counter_pears << std::endl;

    return 0;
}
