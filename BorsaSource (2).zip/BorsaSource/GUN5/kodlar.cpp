#include <iostream>
#include <vector>
#include <string>

int main() {
    std::vector<std::string> kodlar = {"ABC", "DEF", "GHI"};
    for (const auto& k : kodlar)
        std::cout << k << "\n";
    return 0;
}