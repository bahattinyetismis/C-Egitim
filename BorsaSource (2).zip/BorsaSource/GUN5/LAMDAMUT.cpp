
#include <iostream>

int main() {
    int deger = 0;
    auto once = [deger]() mutable {
        deger++;
        std::cout << "deger: " << deger << std::endl;
    };

    once(); // deger: 1
    once(); // deger: 1
    once(); 
}// deger: 1