// Bu dosya, template'lerle yazılmış hisse fonksiyon uygulamasının derleyici tarafından instantiation sonrası oluşmuş halidir.
// Şablon parametreleri yerine konmuş, fonksiyonlar ve sınıflar somutlaştırılmıştır.

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>

// 1️⃣ maxFiyat<double>
double maxFiyat_double(double a, double b) {
    return (a > b) ? a : b;
}

// 2️⃣ Donusturucu<double> ve donustur<int>()
class Donusturucu_double {
    double deger;
public:
    Donusturucu_double(double d) : deger(d) {}

    int donustur_to_int() const {
        return static_cast<int>(deger);
    }
};

// 3️⃣ Overload edilmiş yazdir()
void yazdir_string(const std::string& s) {
    std::cout << "Yazı: " << s << "\n";
}

void yazdir_vector_string(const std::vector<std::string>& v) {
    std::cout << "Genel yazdır (vektör):\n";
    for (const std::string& item : v)
        std::cout << "  " << item << "\n";
}

// 4️⃣ getDefaultLot<int>()
int getDefaultLot_int() {
    return 100;
}

// 5️⃣ sabitIslem<250>()
void sabitIslem_250(const std::string& kod) {
    std::cout << kod << " için otomatik 250 adetlik işlem yapıldı.\n";
}

// 👨‍💻 Ana sınıf: Hisse
class Hisse {
    std::string kod;
    double fiyat;
public:
    Hisse(std::string k, double f) : kod(k), fiyat(f) {}
    double getFiyat() const { return fiyat; }
    std::string getKod() const { return kod; }

    void yaz() const {
        std::cout << std::fixed << std::setprecision(2);
        std::cout << kod << ": " << fiyat << " TL\n";
    }
};

int main() {
    std::cout << "📈 Fonksiyon Şablonu ile Hisse Senedi Örneği\n\n";

    Hisse h1("AKBNK", 37.5);
    Hisse h2("SISE", 52.3);
    h1.yaz();
    h2.yaz();

    std::cout << "\n1️⃣ maxFiyat<T>() kullanımı:\n";
    std::cout << "En yüksek fiyat: " << maxFiyat_double(h1.getFiyat(), h2.getFiyat()) << " TL\n";

    std::cout << "\n2️⃣ Donusturucu<T>::donustur<U>() kullanımı:\n";
    Donusturucu_double d(h1.getFiyat());
    int yuvarlanmis = d.donustur_to_int();
    std::cout << h1.getKod() << " fiyatı yuvarlanmış: " << yuvarlanmis << "\n";

    std::cout << "\n3️⃣ Overloaded yazdir():\n";
    yazdir_string("Fiyatlar Listesi");
    std::vector<std::string> kodlar = { "AKBNK", "SISE", "FROTO" };
    yazdir_vector_string(kodlar);

    std::cout << "\n4️⃣ Varsayılan şablon tipi:\n";
    auto lot = getDefaultLot_int();
    std::cout << "Varsayılan lot miktarı: " << lot << "\n";

    std::cout << "\n5️⃣ Non-type parametreli fonksiyon şablonu:\n";
    sabitIslem_250("THYAO");

    return 0;
}
