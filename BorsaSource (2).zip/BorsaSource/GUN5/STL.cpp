#include <algorithm>
#include <vector>
#include <execution>   // par policies
#include <random>
#include <iostream>
#include <chrono>

int main() {
    std::vector<int> big(1'000'000);
    std::mt19937 rng{1337};
    std::generate(big.begin(), big.end(), rng);

    // Sıralama öncesi zamanı al
    auto start = std::chrono::high_resolution_clock::now();

    // İlk 10 elemanı sıralamadan önce logla
    std::cout << "Ilk 10 eleman (siralama oncesi): ";
    for (int i = 0; i < 10; ++i)
        std::cout << big[i] << ' ';
    std::cout << '\n';

    std::sort(std::execution::par, big.begin(), big.end());

    // Sıralama sonrası zamanı al
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    // İlk 10 elemanı sıralamadan sonra logla
    std::cout << "Ilk 10 eleman (siralama sonrasi): ";
    for (int i = 0; i < 10; ++i)
        std::cout << big[i] << ' ';
    std::cout << '\n';

    std::cout << "Siralama suresi: " << duration << " ms\n";
}