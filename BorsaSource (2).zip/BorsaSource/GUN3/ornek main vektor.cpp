#include <iostream>
#include <string>
#include <vector>
#include <memory>  // smart pointer için

class Stock {
private:
    std::string symbol;
    std::string companyName;
    double price;

public:
    // Constructor
    Stock(const std::string& sym, const std::string& name, double pr)
        : symbol(sym), companyName(name), price(pr) {
        std::cout << "Constructor: " << symbol << "\n";
    }

    // Destructor
    ~Stock() {
        std::cout << "Destructor: " << symbol << "\n";
    }

    void printInfo() const {
        std::cout << "Symbol: " << symbol
                  << ", Company: " << companyName
                  << ", Price: " << price << " TL\n";
    }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

int main() {
    // Vektör içinde smart pointer'larla hisse senetleri tut
    std::vector<std::shared_ptr<Stock>> portfolio;

    // Yeni hisseleri ekle
    portfolio.push_back(std::make_shared<Stock>("AKBNK", "Akbank", 33.5));
    portfolio.push_back(std::make_shared<Stock>("ASELS", "Aselsan", 80.2));
    portfolio.push_back(std::make_shared<Stock>("KCHOL", "Koç Holding", 75.0));

    // Tüm portföyü yazdır
    std::cout << "\n--- Portföy Listesi ---\n";
    for (const auto& stockPtr : portfolio) {
        stockPtr->printInfo();  // pointer üzerinden erişim
    }

    // Bir hissenin fiyatını güncelle
    portfolio[1]->setPrice(82.0);  // ASELS

    std::cout << "\n--- Güncellenmiş Portföy ---\n";
    for (const auto& stockPtr : portfolio) {
        stockPtr->printInfo();
    }

    // program bitince shared_ptr otomatik olarak destructor çağırır
    return 0;
}
