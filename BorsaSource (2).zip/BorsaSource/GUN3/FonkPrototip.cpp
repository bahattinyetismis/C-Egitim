#include <iostream>

// Fonksiyon prototipi
double karZararHesapla(double alisFiyati, double satisFiyati, int adet);

int main() {
    double alis = 10.5;
    double satis = 12.0;
    int adet = 100;

    double kar = karZararHesapla(alis, satis, adet);

    std::cout << "Toplam Kar/Zarar: " << kar << " TL" << std::endl;

    return 0;
}

// Fonksiyon tanımı (definition)
double karZararHesapla(double alisFiyati, double satisFiyati, int adet) {
    return (satisFiyati - alisFiyati) * adet;
}
