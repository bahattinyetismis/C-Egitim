#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <functional>

class Order {
    std::string symbol_;
    int quantity_{0};
    double price_{0.0};

    // Lambda'dan erişilebilir ama const fonksiyonda değişebilir olmalı
    mutable bool isPreviewed_ = false;

public:
    // Chaining desteği için her setter, *this döner
    Order& setSymbol(const std::string& sym) {
        symbol_ = sym;
        return *this;  // this → Order* → *this → Order&
    }

    Order& setQuantity(int qty) {
        quantity_ = qty;
        return *this;
    }

    Order& setPrice(double pr) {
        price_ = pr;
        return *this;
    }

    void preview() const {
        // mutable değişkeni const fonksiyonda değiştirebiliriz
        isPreviewed_ = true;

        std::cout << "[Önizleme] " << quantity_ << " adet " << symbol_
                  << " emri @" << price_ << " TL\n";
    }

    void execute() const {
        if (!isPreviewed_)
            std::cout << "⚠ Önizleme yapılmadan emir gönderiliyor...\n";
        std::cout << "✅ " << quantity_ << " adet " << symbol_ << " satın alındı @" << price_ << " TL\n";
    }
};

int main() {
    // smart pointer ile dinamik emir oluşturma
    std::shared_ptr<Order> order = std::make_shared<Order>();

    // chaining + this + lambda + smart pointer
    auto build = [order]() -> std::shared_ptr<Order> {
        return order->setSymbol("ASELS")
                    .setQuantity(100)
                    .setPrice(87.5);
    };

    auto o = build();  // zincirleme ayarla

    o->preview();  // const + mutable örneği
    o->execute();  // emir gönder

    return 0;
}