#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

// Veri yapısı
struct Stock {
    std::string sym;
    double price;
};

// Lambda yerine kullanılacak klasik fonksiyon
bool compareByPriceDesc(const Stock& a, const Stock& b) {
    std::cout << "Karşılaştır: " << a.sym << "(" << a.price << ") vs "
              << b.sym << "(" << b.price << ") → "
              << (a.price > b.price ? "true" : "false") << '\n';
    return a.price > b.price;
}

int main() {
    std::vector<Stock> list{
        {"AAPL", 208},
        {"GOOG", 305},
        {"NVDA", 290},
        {"MSFT", 405}
    };

    std::cout << "🔍 Karşılaştırmalar:\n";
    std::sort(list.begin(), list.end(), compareByPriceDesc);  // lambda yerine fonksiyon adı

    std::cout << "\n✅ Sıralı Liste (Büyükten Küçüğe):\n";
    for (const auto& s : list)
        std::cout << s.sym << ": " << s.price << '\n';
}

