#include <algorithm>
#include <vector>
#include <iostream>

int main() {
    std::vector<int> in {1,2,3,4};
    std::vector<int> out(in.size());

    std::transform(in.begin(), in.end(), out.begin(),
                   [](int x){ return x * x; });     // karesini al
    for (int n : out) std::cout << n << ' ';       // 1 4 9 16
}
