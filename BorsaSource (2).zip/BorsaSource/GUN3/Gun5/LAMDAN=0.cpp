#include <algorithm>
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v{1, 2, 3, 4};
    int sum = 0;   // Toplamı tutacak değişken
    int fark = 0;  // Farkı tutacak değişken

    std::for_each(v.begin(), v.end(),
                  [&](int x) {
                      sum += x;   // Toplama
                      fark -= x;  // Çıkarma
                  });

    std::cout << "Toplam = " << sum << '\n'; // 10
    // std::cout << "Fark = " << fark << '\n';  // -10

    return 0;
}
