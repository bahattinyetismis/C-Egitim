#include <algorithm>
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v{4,1,2,2,3,4,1};

    std::cout << "Ilk hali: ";
    for (int n : v) std::cout << n << ' ';
    std::cout << '\n';

    std::sort(v.begin(), v.end());
    std::cout << "Sort sonrasi: ";
    for (int n : v) std::cout << n << ' ';
    std::cout << '\n';

    auto last = std::unique(v.begin(), v.end());
    std::cout << "Unique sonrasi: ";
    for (int n : v) std::cout << n << ' ';
    std::cout << '\n';

    v.erase(last, v.end());
    std::cout << "Erase sonrasi: ";
    for (int n : v) std::cout << n << ' ';
    std::cout << '\n';
}
