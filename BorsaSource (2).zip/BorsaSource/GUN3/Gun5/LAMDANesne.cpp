#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

// Bir nesne (class/struct) tanımlayalım
struct Ogrenci {
    std::string ad;
    int notu;

    void yazdir() const {
        std::cout << ad << " - Not: " << notu << std::endl;
    }
};

int main() {
    std::vector<Ogrenci> sinif = {
        {"Ali", 85},
        {"Ayse", 92},
        {"Mehmet", 78},
        {"Zeynep", 95}
    };

    // 1. Lambda ile notu 90'dan büyük olanları ekrana bas
    std::cout << "Basarili ogrenciler:\n";
    std::for_each(sinif.begin(), sinif.end(),
        [](const Ogrenci& ogr) {
            if (ogr.notu > 90)
                ogr.yazdir();
        });

    // 2. Lambda ile tüm notları 5 puan artır
    std::for_each(sinif.begin(), sinif.end(),
        [](Ogrenci& ogr) {
            ogr.notu += 5;
        });

    // 3. Lambda ile güncellenmiş tüm öğrencileri ekrana bas
    std::cout << "\nGuncel notlar:\n";
    std::for_each(sinif.begin(), sinif.end(),
        [](const Ogrenci& ogr) {
            ogr.yazdir();
        });

    return 0;
}