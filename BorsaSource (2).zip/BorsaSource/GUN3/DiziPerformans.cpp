#include <iostream>
#include <vector>
#include <chrono>
int main() {
    constexpr std::size_t N = 1'000'000;

    // statik (global) için derleme-zamanı sabit gerekli
    static int sabit[N]{};

    auto t1 = std::chrono::high_resolution_clock::now();
    for (int& x : sabit) x = 1;
    auto t2 = std::chrono::high_resolution_clock::now();

    std::vector<int> din(N);
    for (int& x : din) x = 1;
    auto t3 = std::chrono::high_resolution_clock::now();

    std::cout << "Statik   ms: "
              << std::chrono::duration<double, std::milli>(t2-t1).count() << '\n'
              << "Dinamik  ms: "
              << std::chrono::duration<double, std::milli>(t3-t2).count() << '\n';
}