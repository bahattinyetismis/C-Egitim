#include <iostream>

int main() {
    int hit = 0;
    auto click = [&] {                // &  ⇒ hit referans
        std::cout << ++hit << '\n';
    };

    auto once = [n = 0]() mutable {   // kopya ama değiştirilebilir
        std::cout << ++n << '\n';
    };

    click(); click();    // 1 2
    once(); once();      // 1 2  (iç kopya değişti)
}
