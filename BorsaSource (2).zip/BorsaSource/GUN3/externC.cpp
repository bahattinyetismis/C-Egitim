#include <iostream>

// C bağlantı kurallarıyla bildirilen fonksiyon (header gibi düşün)
extern "C" double karZararHesapla(double alisFiyati, double satisFiyati, int adet);

int main() {
    double alis = 10.5;
    double satis = 12.0;
    int adet = 100;

    double kar = karZararHesapla(alis, satis, adet);

    std::cout << "Toplam Kar/Zarar: " << kar << " TL" << std::endl;

    return 0;
}

// Fonksiyon tanımı da C bağlantısıyla olmalıysa:
extern "C" double karZararHesapla(double alisFiyati, double satisFiyati, int adet) {
    return (satisFiyati - alisFiyati) * adet;
}
