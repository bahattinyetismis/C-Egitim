#include <iostream>
#include <vector>
#include <memory>

// --------------------------------------
// Soyut sınıf (abstract base class)
// --------------------------------------
class Stock {
protected:
    std::string symbol;
    double price;

public:
    Stock(std::string sym, double pr) : symbol(sym), price(pr) {}

    // Saf sanal fonksiyon
    virtual void analyze() const = 0;

    // Kendini loglayan fonksiyon (this kullanımı)
    void logSelf() const {
        std::cout << "[LOG] Hisse: " << symbol << ", Fiyat: " << price << "\n";
    }

    // Bu fonksiyon zincirleme yapı için *this kullanır
    const Stock& logAndReturn() const {
        logSelf();           // kendi log fonksiyonunu çağır
        return *this;        // kendi referansını döndür
    }

    virtual ~Stock() = default;
};

// --------------------------------------
// Türetilmiş sınıf: TechStock
// --------------------------------------
class TechStock : public Stock {
public:
    TechStock(std::string sym, double pr) : Stock(sym, pr) {}

    void analyze() const override {
        std::cout << "[Tech] " << symbol << " için Ar-Ge odaklı analiz yapılır.\n";
    }
};

// --------------------------------------
// Türetilmiş sınıf: EnergyStock
// --------------------------------------
class EnergyStock : public Stock {
public:
    EnergyStock(std::string sym, double pr) : Stock(sym, pr) {}

    void analyze() const override {
        std::cout << "[Energy] " << symbol << " için enerji piyasası analizi yapılır.\n";
    }
};

// --------------------------------------
// Polimorfik analiz fonksiyonu
// --------------------------------------
void runAnalysis(const Stock& s) {
    s.logAndReturn().analyze();  // *this ile zincirleme analiz çağrısı
}

// --------------------------------------
// main
// --------------------------------------
int main() {
    std::vector<std::unique_ptr<Stock>> portfolio;
    portfolio.emplace_back(std::make_unique<TechStock>("ASELS", 89.5));
    portfolio.emplace_back(std::make_unique<EnergyStock>("TUPRS", 141.0));

    for (const auto& stock : portfolio) {
        runAnalysis(*stock);  // polymorphic + *this örneği
    }
}
