#include <iostream>
#include <vector>
#include <memory>
#include <string>

class Stock {
private:
    std::string symbol;
    double price;
public:
    Stock(const std::string& sym, double pr) : symbol(sym), price(pr) {
        std::cout << "Constructed: " << symbol << "\n";
    }

    ~Stock() {
        std::cout << "Destructed: " << symbol << "\n";
    }

    void print() const {
        std::cout << "Stock: " << symbol << ", Price: " << price << "\n";
    }
};

// 1️⃣ Class içinde vector<Stock>
class Portfolio1 {
public:
    std::vector<Stock> stocks;
    void add(const Stock& s) { stocks.push_back(s); }
    void show() {
        std::cout << "Portfolio1:\n";
        for (auto& s : stocks) s.print();
    }
};

// 2️⃣ Class içinde vector<shared_ptr<Stock>>
class Portfolio2 {
public:
    std::vector<std::shared_ptr<Stock>> stocks;
    void add(std::shared_ptr<Stock> s) { stocks.push_back(s); }
    void show() {
        std::cout << "Portfolio2:\n";
        for (auto& s : stocks) s->print();
    }
};

// 3️⃣ Class içinde Stock array (sabit boyut)
class Portfolio3 {
public:
    Stock a{"AKBNK", 33.5};
    Stock b{"KCHOL", 75.0};
    void show() {
        std::cout << "Portfolio3:\n";
        a.print();
        b.print();
    }
};

int main() {
    std::cout << "\n🧱 Class içi vector<Stock>\n";
    Portfolio1 p1;
    p1.add(Stock("ASELS", 80.2));
    p1.show();

    std::cout << "\n🧱 Class içi vector<shared_ptr<Stock>>\n";
    Portfolio2 p2;
    p2.add(std::make_shared<Stock>("SISE", 42.1));
    p2.show();

    std::cout << "\n🧱 Class içi sabit üyeler (Stock)\n";
    Portfolio3 p3;
    p3.show();

    std::cout << "\n📦 main içi vector<Stock>\n";
    std::vector<Stock> stocksMain;
    stocksMain.emplace_back("FROTO", 98.5);
    for (auto& s : stocksMain) s.print();

    std::cout << "\n📦 main içi vector<shared_ptr<Stock>>\n";
    std::vector<std::shared_ptr<Stock>> stockPtrs;
    stockPtrs.push_back(std::make_shared<Stock>("TOASO", 51.1));
    for (auto& s : stockPtrs) s->print();

    return 0;
}
