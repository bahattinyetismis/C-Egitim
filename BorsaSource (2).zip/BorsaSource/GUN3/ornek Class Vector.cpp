#include <iostream>
#include <string>
#include <vector>
#include <memory>  // smart pointer

// Hisse sınıfı
class Stock {
private:
    std::string symbol;
    std::string companyName;
    double price;

public:
    Stock(const std::string& sym, const std::string& name, double pr)
        : symbol(sym), companyName(name), price(pr) {
        std::cout << "Constructor: " << symbol << "\n";
    }

    ~Stock() {
        std::cout << "Destructor: " << symbol << "\n";
    }

    void printInfo() const {
        std::cout << "Symbol: " << symbol
                  << ", Company: " << companyName
                  << ", Price: " << price << " TL\n";
    }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// Portföy sınıfı (vektör burada)
class Portfolio {
private:
    std::vector<std::shared_ptr<Stock>> stocks;

public:
    void addStock(const std::string& sym, const std::string& name, double price) {
        stocks.push_back(std::make_shared<Stock>(sym, name, price));
    }

    void printAll() const {
        std::cout << "\n--- Portföy Listesi ---\n";
        for (const auto& s : stocks) {
            s->printInfo();
        }
    }

    void updatePrice(int index, double newPrice) {
        if (index >= 0 && index < stocks.size()) {
            stocks[index]->setPrice(newPrice);
        }
    }
};

int main() {
    Portfolio myPortfolio;

    myPortfolio.addStock("AKBNK", "Akbank", 33.5);
    myPortfolio.addStock("ASELS", "Aselsan", 80.2);
    myPortfolio.addStock("KCHOL", "Koç Holding", 75.0);

    myPortfolio.printAll();

    // Fiyat güncelle (ASELS)
    myPortfolio.updatePrice(1, 82.0);

    std::cout << "\n--- Güncellenmiş Portföy ---\n";
    myPortfolio.printAll();

    return 0;
}
