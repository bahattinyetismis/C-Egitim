#include <iostream>
#include <cstdlib> // malloc, free

struct Foo {
    int x;
    Foo(int i) : x(i) {
        std::cout << "Ctor: " << x << '\n';
    }
    ~Foo() {
        std::cout << "Dtor: " << x << '\n';
    }
};

int main() {
    std::size_t N = 3;
    
    std::cout << "=== Memory Allocation and Address Analysis ===" << std::endl;
    std::cout << "=============================================" << std::endl;
    
    // Allocate memory
    void* raw = std::malloc(sizeof(Foo) * N);
    Foo* arr = static_cast<Foo*>(raw);
    
    std::cout << "\n1. ADDRESSES AND SIZES:" << std::endl;
    std::cout << "------------------------" << std::endl;
    std::cout << "sizeof(Foo) = " << sizeof(Foo) << " bytes" << std::endl;
    std::cout << "N = " << N << std::endl;
    std::cout << "Total allocated size = " << sizeof(Foo) * N << " bytes" << std::endl;
    std::cout << "raw address (void*) = " << raw << std::endl;
    std::cout << "arr address (Foo*) = " << arr << std::endl;
    std::cout << "raw == arr: " << (raw == arr ? "true" : "false") << std::endl;
    
    std::cout << "\n2. VOID* CONTENT (raw pointer):" << std::endl;
    std::cout << "--------------------------------" << std::endl;
    std::cout << "raw points to: " << raw << std::endl;
    std::cout << "raw + 1: " << static_cast<char*>(raw) + 1 << std::endl;
    std::cout << "raw + sizeof(Foo): " << static_cast<char*>(raw) + sizeof(Foo) << std::endl;
    
    // Show raw memory content (before object construction)
    std::cout << "\nRaw memory content (before objects):" << std::endl;
    unsigned char* rawBytes = static_cast<unsigned char*>(raw);
    for (std::size_t i = 0; i < sizeof(Foo) * N; ++i) {
        std::cout << "Byte " << i << ": 0x" << std::hex << static_cast<int>(rawBytes[i]) << std::dec;
        if ((i + 1) % sizeof(Foo) == 0) std::cout << " | ";
        else std::cout << " ";
    }
    std::cout << std::endl;
    
    std::cout << "\n3. FOO* CONTENT (arr pointer):" << std::endl;
    std::cout << "-------------------------------" << std::endl;
    std::cout << "arr points to: " << arr << std::endl;
    std::cout << "arr + 1: " << arr + 1 << std::endl;
    std::cout << "arr + 2: " << arr + 2 << std::endl;
    
    // Calculate individual object addresses
    for (std::size_t i = 0; i < N; ++i) {
        std::cout << "arr[" << i << "] address: " << &arr[i] << std::endl;
        std::cout << "arr[" << i << "] offset: " << (static_cast<char*>(&arr[i]) - static_cast<char*>(raw)) << " bytes" << std::endl;
    }
    
    std::cout << "\n4. OBJECT CONSTRUCTION:" << std::endl;
    std::cout << "------------------------" << std::endl;
    
    // Construct objects using placement new
    for (std::size_t i = 0; i < N; ++i) {
        std::cout << "Constructing Foo(" << (i + 10) << ") at address: " << &arr[i] << std::endl;
        new (&arr[i]) Foo(i + 10);  // placement new
    }
    
    std::cout << "\n5. FOO* CONTENT AFTER CONSTRUCTION:" << std::endl;
    std::cout << "------------------------------------" << std::endl;
    
    // Show object contents
    for (std::size_t i = 0; i < N; ++i) {
        std::cout << "arr[" << i << "].x = " << arr[i].x << " (at address: " << &arr[i] << ")" << std::endl;
    }
    
    // Show memory content after construction
    std::cout << "\nMemory content after object construction:" << std::endl;
    for (std::size_t i = 0; i < sizeof(Foo) * N; ++i) {
        std::cout << "Byte " << i << ": 0x" << std::hex << static_cast<int>(rawBytes[i]) << std::dec;
        if ((i + 1) % sizeof(Foo) == 0) std::cout << " | ";
        else std::cout << " ";
    }
    std::cout << std::endl;
    
    std::cout << "\n6. USAGE EXAMPLE:" << std::endl;
    std::cout << "-----------------" << std::endl;
    std::cout << "arr[1].x = " << arr[1].x << std::endl;
    
    std::cout << "\n7. CLEANUP:" << std::endl;
    std::cout << "------------" << std::endl;
    
    // Manual destructor calls
    for (std::size_t i = 0; i < N; ++i) {
        std::cout << "Destroying Foo at address: " << &arr[i] << std::endl;
        arr[i].~Foo();              // destructor elle çağır
    }
    
    // Free memory
    std::cout << "Freeing memory at address: " << raw << std::endl;
    std::free(raw);  // bellek serbest
    
    std::cout << "\n=== Program completed successfully ===" << std::endl;
    
    return 0;
}
