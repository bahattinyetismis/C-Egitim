#include <iostream>

int main() {
    int hit = 0;

    auto click = [&] {                // & ⇒ hit değişkenini referansla yakalar
        std::cout << ++hit << '\n';   // hit her çağrıldığında 1 artar
    };

    auto once = [n = 0]() mutable {   // n kopyalanır, ama değiştirilebilir (mutable)
        std::cout << ++n << '\n';     // n sadece bu lambda'nın içinde artar
    };

    click(); click();    // hit = 1, sonra 2
    once(); once();      // n = 1, sonra yine 2 (farklı kopya!)
}
