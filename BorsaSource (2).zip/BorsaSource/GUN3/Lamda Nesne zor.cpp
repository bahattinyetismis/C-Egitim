#include <iostream>
#include <memory>
#include <string>

class Order {
    std::string symbol_;
    int quantity_{0};
    double price_{0.0};

public:
    Order& setSymbol(const std::string& sym) {
        symbol_ = sym;
        return *this;
    }

    Order& setQuantity(int qty) {
        quantity_ = qty;
        return *this;
    }

    Order& setPrice(double pr) {
        price_ = pr;
        return *this;
    }

    void preview() const {
        std::cout << "[Önizleme] " << quantity_ << " adet " << symbol_
                  << " emri @" << price_ << " TL\n";
    }
};

int main() {
    // 1. shared_ptr ile sipariş oluştur
    std::shared_ptr<Order> order = std::make_shared<Order>();

    // 2. Lambda order'ı yakalıyor (kopya olarak)
    auto build = [order]()  {
        return order->setSymbol("XYZ")
                    .setQuantity(50)
                    .setPrice(150.0);
        return order;
    };

    // 3. Lambda'yı çağır ve sonucu al
    auto finalOrder = build();

    // 4. Önizlemeyi göster
    finalOrder->preview();

    return 0;
}
