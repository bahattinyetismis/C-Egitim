#include <algorithm>
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v{1,2,3,4};
    int sum = 0;

    std::for_each(v.begin(), v.end(),
                  [&](int x){ sum += x; });      // [&] = sum’ı referansla yakala

    std::cout << "Toplam = " << sum << '\n';     // 10
}
