#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <functional>

class Order {
    std::string symbol_;
    int quantity_{0};
    double price_{0.0};

    mutable bool isPreviewed_ = false;

public:
    // Sembolü ayarlayan fonksiyon (zincirleme için Order& döndürür)
    Order& setSymbol(const std::string& sym) {
        symbol_ = sym;
        return *this;
    }

    // Miktarı ayarlayan fonksiyon (zincirleme için Order& döndürür)
    Order& setQuantity(int qty) {
        quantity_ = qty;
        return *this;
    }

    // Fiyatı ayarlayan fonksiyon (zincirleme için Order& döndürür)
    Order& setPrice(double pr) {
        price_ = pr;
        return *this;
    }

    // Siparişi önizleyen fonksiyon
    void preview() const {
        isPreviewed_ = true;
        std::cout << "[Önizleme] " << quantity_ << " adet " << symbol_
                  << " emri @" << price_ << " TL\n";
    }

    // Siparişi gerçekleştiren fonksiyon
    void execute() const {
        if (!isPreviewed_)
            std::cout << "⚠ Önizleme yapılmadan emir gönderiliyor...\n";
        std::cout << "✅ " << quantity_ << " adet " << symbol_ << " satın alındı @" << price_ << " TL\n";
    }
};

int main() {
    // Sipariş nesnesi oluşturup zincirleme şekilde ayarlayan lambda fonksiyonu
    auto build = []() -> std::shared_ptr<Order> {
        auto order = std::make_shared<Order>(); // Akıllı işaretçi ile Order oluştur
        order->setSymbol("ASELS").setQuantity(100).setPrice(87.5); // Zincirleme ayar
        return order; // Ayarlanmış shared_ptr döndür
    };

    // Lambda ile siparişi oluştur
    auto order = build();
    order->preview();  // Önizleme yap
    order->execute();  // Siparişi gerçekleştir
}