#include <iostream>
#include <cstring>

// Function overloads to demonstrate nullptr behavior
void f(int x) {
    std::cout << "f(int) called with value: " << x << std::endl;
}

void f(char* ptr) {
    if (ptr == nullptr) {
        std::cout << "f(char*) called with nullptr" << std::endl;
    } else {
        std::cout << "f(char*) called with pointer: " << ptr << std::endl;
    }
}

// Template function to demonstrate type safety
template<typename T>
void templateFunction(T* ptr) {
    if (ptr == nullptr) {
        std::cout << "Template function: nullptr detected" << std::endl;
    } else {
        std::cout << "Template function: valid pointer" << std::endl;
    }
}

int main() {
    std::cout << "=== Why Use nullptr? ===" << std::endl;
    std::cout << "========================" << std::endl;
    
    // 1. Function Overloading - The Main Problem with NULL
    std::cout << "\n1. FUNCTION OVERLOADING PROBLEM:" << std::endl;
    std::cout << "--------------------------------" << std::endl;
    
    f(0);        // ✅ Clear: calls f(int)
    f((char*)NULL); // ✅ Works but requires explicit cast
    f(nullptr);  // ✅ Perfect: calls f(char*) automatically
    
    // This would cause compilation error:
    // f(NULL);   // ❌ AMBIGUOUS - compiler doesn't know which f() to call
    
    std::cout << "\n2. TYPE SAFETY:" << std::endl;
    std::cout << "---------------" << std::endl;
    
    // NULL is typically #define NULL 0
    int* intPtr1 = NULL;     // Works but confusing
    int* intPtr2 = 0;        // Works but confusing  
    int* intPtr3 = nullptr;  // ✅ Clear intent - this is a null pointer
    
    char* charPtr1 = NULL;   // Works but confusing
    char* charPtr2 = nullptr; // ✅ Clear intent
    
    std::cout << "NULL is just 0: " << (NULL == 0) << std::endl;
    std::cout << "nullptr is not 0: " << (nullptr == 0) << std::endl;
    std::cout << "nullptr type: " << typeid(nullptr).name() << std::endl;
    
    std::cout << "\n3. TEMPLATE SAFETY:" << std::endl;
    std::cout << "------------------" << std::endl;
    
    int* ptr1 = nullptr;
    char* ptr2 = nullptr;
    double* ptr3 = nullptr;
    
    templateFunction(ptr1);  // Works with nullptr
    templateFunction(ptr2);  // Works with nullptr
    templateFunction(ptr3);  // Works with nullptr
    
    std::cout << "\n4. COMPARISON EXAMPLES:" << std::endl;
    std::cout << "----------------------" << std::endl;
    
    int* testPtr = nullptr;
    
    // All these comparisons work correctly with nullptr:
    if (testPtr == nullptr) std::cout << "✓ Equal to nullptr" << std::endl;
    if (testPtr != nullptr) std::cout << "✗ Not equal to nullptr" << std::endl;
    if (!testPtr) std::cout << "✓ Boolean conversion works" << std::endl;
    
    std::cout << "\n5. PRACTICAL EXAMPLES:" << std::endl;
    std::cout << "---------------------" << std::endl;
    
    // Example 1: Function that may return a pointer or nullptr
    char* findCharacter(const char* str, char target) {
        if (str == nullptr) return nullptr;  // ✅ Clear intent
        
        for (int i = 0; str[i] != '\0'; i++) {
            if (str[i] == target) {
                return const_cast<char*>(&str[i]);  // Found it
            }
        }
        return nullptr;  // ✅ Not found
    }
    
    char* result1 = findCharacter("Hello", 'l');
    char* result2 = findCharacter("Hello", 'z');
    
    if (result1 != nullptr) {
        std::cout << "Found 'l' at: " << result1 << std::endl;
    }
    
    if (result2 == nullptr) {
        std::cout << "'z' not found (nullptr returned)" << std::endl;
    }
    
    // Example 2: Class member initialization
    class Example {
    public:
        char* data = nullptr;  // ✅ Clear initialization
        
        Example() : data(nullptr) {}  // ✅ Explicit null pointer
        
        void setData(char* newData) {
            data = newData;  // Could be nullptr or valid pointer
        }
        
        bool hasData() const {
            return data != nullptr;  // ✅ Clear null check
        }
    };
    
    Example obj;
    if (!obj.hasData()) {
        std::cout << "Object has no data (nullptr)" << std::endl;
    }
    
    std::cout << "\n6. SUMMARY - Why nullptr is Better:" << std::endl;
    std::cout << "=====================================" << std::endl;
    std::cout << "✓ Type Safety: nullptr has its own type (std::nullptr_t)" << std::endl;
    std::cout << "✓ No Ambiguity: Won't cause function overloading issues" << std::endl;
    std::cout << "✓ Clear Intent: Explicitly indicates null pointer" << std::endl;
    std::cout << "✓ Template Safe: Works correctly with templates" << std::endl;
    std::cout << "✓ Modern C++: Standard since C++11" << std::endl;
    std::cout << "✓ Consistent: Same behavior across all pointer types" << std::endl;
    
    return 0;
}
