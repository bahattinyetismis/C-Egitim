#include <iostream>

// Deger ile gecis (pass-by-value) - Orjinal degeri DEGISTIRMEZ, sadece kopyasi uzerinde calisir
void degistir_by_value(int val) {
    val += 10; // Bu degisiklik sadece kopyayi etkiler
    std::cout << "Fonksiyon icinde (kopya): " << val << std::endl; // Kopyanin degeri
}

int main() {
    int sayi = 5;
    std::cout << "Fonksiyon cagrilmadan once: " << sayi << std::endl;

    degistir_by_value(sayi); // sayi değişkeninin bir kopyasini gonderiyoruz

    std::cout << "Fonksiyon cagrildiktan sonra: " << sayi << std::endl; // Cikti: 5 (degismedi!)
    return 0;
} 