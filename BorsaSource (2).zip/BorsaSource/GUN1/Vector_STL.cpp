#include <iostream>    // std::cout için
#include <vector>      // std::vector için
#include <numeric>     // std::accumulate için

int main() {
    std::vector<int> v{1, 2, 3, 4, 5};

    // Açıklanacak komut:
    int toplam = std::accumulate(v.begin(), v.end(), 0);

    // Sonucu loga yazdır
    std::cout << "Vektördeki elemanların toplamı: " << toplam << std::endl;

    return 0;
}