#include <iostream>

class MyClass {
public:
    int _data;
    mutable int _cache; // Bu değişken 'mutable' olarak işaretlendi

    MyClass(int data) : _data(data), _cache(0) {}

    // Bu fonksiyon 'const' olarak işaretlenmiş.
    // Normalde '_data' veya '_cache' değerini değiştiremezdi.
    int getValue() const {
        // 'const' fonksiyon olmamıza rağmen '_cache' değerini değiştirebiliriz
        // çünkü '_cache' 'mutable' olarak tanımlanmıştır.
        _cache++; // Bu satır 'mutable' olmasaydı derleme hatası verirdi.

        std::cout << "Cache değeri arttırıldı: " << _cache << std::endl;
        return _data;
    }

    // Normal bir fonksiyon, hem _data hem de _cache değiştirebilir
    void setData(int newData) {
        _data = newData;
        _cache = 0; // _cache'i sıfırla
    }
};

int main() {
    MyClass obj(10); // 'obj' bir const nesne değil, ama 'getValue()' const.

    std::cout << "İlk değer: " << obj.getValue() << std::endl; // Cache 1 olur
    std::cout << "İkinci değer: " << obj.getValue() << std::endl; // Cache 2 olur
    std::cout << "Üçüncü değer: " << obj.getValue() << std::endl; // Cache 3 olur

    // 'const MyClass constObj(20);' olsaydı bile:
    // constObj.getValue(); // hala çalışırdı ve constObj._cache'i değiştirirdi.

    return 0;
}