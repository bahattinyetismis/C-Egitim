#include <iostream>

int main() {
    int x = 42;
    int* px = &x;            // pointer
    int& rx = x;             // reference (cannot be null)
    
    std::cout << "Value of x: " << x << std::endl;
    std::cout << "Address of x: " << &x << std::endl;
    
    std::cout << "\nPointer (px) demonstration:" << std::endl;
    std::cout << "Address stored in px: " << px << std::endl;
    std::cout << "Value pointed to by px: " << *px << std::endl;
    std::cout << "Address of px itself: " << &px << std::endl;
    
    std::cout << "\nReference (rx) demonstration:" << std::endl;
    std::cout << "Value of rx: " << rx << std::endl;
    std::cout << "Address of rx: " << &rx << std::endl;
    
    // Modifying the value through pointer
    *px = 100;
    std::cout << "\nAfter modifying through pointer:" << std::endl;
    std::cout << "Value of x: " << x << std::endl;
    std::cout << "Value of rx: " << rx << std::endl;
    
    // Modifying the value through reference
    rx = 200;
    std::cout << "\nAfter modifying through reference:" << std::endl;
    std::cout << "Value of x: " << x << std::endl;
    std::cout << "Value pointed to by px: " << *px << std::endl;    

} 