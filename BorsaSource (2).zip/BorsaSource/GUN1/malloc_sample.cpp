#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main() {
    void* hamBellek = malloc(64);

    if (hamBellek == NULL) {
        printf("Bellek tahsisi başarısız!\n");
        return 1;
    }

    // Örneğin, bu belleği bir karakter dizisi olarak kullanalım:
    strcpy((char*)hamBellek, "Merhaba, dinamik bellek!");

    printf("İçerik: %s\n", (char*)hamBellek);

    // Belleği serbest bırakmayı unutma!
    free(hamBellek);
    return 0;
}
