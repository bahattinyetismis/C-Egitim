#include <iostream>               // Giriş/çıkış işlemleri
#include <memory>                 // smart pointer'lar

constexpr double PRICE_THRESHOLD = 200.0;     // Derleme zamanı sabit
inline bool isExpensive(double p) { return p > PRICE_THRESHOLD; } // Fonksiyon olarak karşılaştırma
inline void debugLog(const std::string& msg) { std::cout << "[DEBUG] " << msg << '\n'; } // Fonksiyonel log

class Stock {
public:
    std::string symbol;           // Hisse sembolü
    double price;                 // Hisse fiyatı

    Stock(std::string s, double p) : symbol(s), price(p) {}  // Kurucu

    void print() const {
        std::cout << symbol << ": $" << price;               // Yazdırma işlemi
        if (isExpensive(price)) std::cout << " Expensive!";  // Kontrol fonksiyonla yapılır
        std::cout << '\n';
    }
};

int main() {
    std::shared_ptr<Stock> s = std::make_shared<Stock>("TSLA", 310); // Akıllı pointer
    s->print();                         // Detayları yazdır
    debugLog("Fiyat kontrol edildi."); // Log bas
    return 0;
}
