#include <iostream>
#include <unordered_map>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <chrono>

// Hisse bilgisi yapısı
struct Hisse {
    std::string adi;
    double tutar;
    long volume;
};

// Ana veri yapısı: hisse kodu → hisse bilgisi
std::unordered_map<std::string, Hisse> tablo;

// Tablo bazlı mutex (eşzamanlılık için)
std::mutex tabloMutex;

// Her hisse için tekil erişim: hisse kodu → mutex
std::unordered_map<std::string, std::mutex*> hisseMutexleri;
std::mutex mutexMapMutex; // hisse mutexlerini yönetmek için mutex

// Hisse güncelleme fonksiyonu (her hisse için kendi mutexi ile kilitli)
void hisseyiGuncelle(const std::string& kod, const std::string& adi, double yeniTutar, long yeniVol) {
    std::scoped_lock tabloLock(tabloMutex);
    {
        std::scoped_lock lock(mutexMapMutex);
        if (hisseMutexleri.find(kod) == hisseMutexleri.end()) {
            hisseMutexleri[kod] = new std::mutex();
        }
    }
    hisseMutexleri[kod]->lock();
    // Eski fiyatı bul
    double eskiFiyat = 0.0;
    bool vardi = false;
    auto it = tablo.find(kod);
    if (it != tablo.end()) {
        eskiFiyat = it->second.tutar;
        vardi = true;
    }
    // 📌 Kritik bölge: hisse güncelleniyor
    tablo[kod] = {adi, yeniTutar, yeniVol};
    if (vardi) {
        std::cout << "[" << kod << "] güncellendi: Eski fiyat: " << eskiFiyat << " TL, Yeni fiyat: " << yeniTutar << " TL, hacim: " << yeniVol << "\n";
    } else {
        std::cout << "[" << kod << "] eklendi: Fiyat: " << yeniTutar << " TL, hacim: " << yeniVol << "\n";
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    hisseMutexleri[kod]->unlock();
}

int main() {
    // 6 eş zamanlı hisse güncellemesi tanımla (bir tanesi aynı hissede çalışacak)
    std::vector<std::thread> threadler;
    threadler.emplace_back(hisseyiGuncelle, "AKBNK", "Akbank", 37.5, 12000000);
    threadler.emplace_back(hisseyiGuncelle, "GARAN", "Garanti", 54.9, 18000000);
    threadler.emplace_back(hisseyiGuncelle, "SISE", "Sise Cam", 51.9, 8700000);
    threadler.emplace_back(hisseyiGuncelle, "THYAO", "THY", 310.7, 8500000);
    threadler.emplace_back(hisseyiGuncelle, "FROTO", "Ford", 1020.1, 3200000);
    threadler.emplace_back(hisseyiGuncelle, "AKBNK", "Akbank", 38.2, 12500000); // Aynı hisse ikinci kez
    for (auto& t : threadler) t.join();

    std::cout << "\n📋 Güncel tablo:\n";
    for (const auto& [kod, hisse] : tablo) {
        std::cout << kod << " → " << hisse.adi << ", " << hisse.tutar << " TL, Volume: " << hisse.volume << "\n";
    }

    // Bellek temizliği
    for (auto& [kod, mtx] : hisseMutexleri) delete mtx;
    return 0;
}
