#include <iostream>

#define DECL_COUNTER(name) int counter_##name = 0
#define INCR_COUNTER(name) counter_##name++

int main() {
    // Declare counters
    DECL_COUNTER(apples);
    DECL_COUNTER(oranges);
    DECL_COUNTER(pears);

    // Increment counters
    INCR_COUNTER(apples);        // counter_apples++
    INCR_COUNTER(oranges);
    INCR_COUNTER(oranges);
    INCR_COUNTER(pears);
    INCR_COUNTER(pears);
    INCR_COUNTER(pears);

    // Print values
    std::cout << "Apples: " << counter_apples << std::endl;
    std::cout << "Oranges: " << counter_oranges << std::endl;
    std::cout << "Pears: " << counter_pears << std::endl;

    return 0;
}
