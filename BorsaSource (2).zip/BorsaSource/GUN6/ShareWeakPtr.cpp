#include <memory>
#include <iostream>

struct Node {
    std::shared_ptr<Node> next;
    std::weak_ptr<Node>   prev; // Cycle'ı önlemek için
};

int main() {
    auto n1 = std::make_shared<Node>();
    auto n2 = std::make_shared<Node>();
    n1->next = n2;
    n2->prev = n1;               // weak_ptr döngüyü kırar
    std::cout << n1.use_count() << std::endl; // 1
} 