#include <memory>     // shared_ptr ve weak_ptr için
#include <iostream>   // std::cout için
#include <string>     // std::string için

// 📦 Hisse senedi düğüm yapısı
struct StockNode {
    std::string symbol;                                // Hisse kodu (örnek: "AAPL")
    std::shared_ptr<StockNode> next;                   // Sonraki hisseye işaret eder
    std::weak_ptr<StockNode> prev;                     // Önceki hisseye işaret eder (zayıf referans)

    // Kurucu fonksiyon: hisse oluşturulunca çağrılır
    StockNode(const std::string& s) : symbol(s) {
        std::cout << "[Init] " << symbol << " created.\n";
    }

    // Yıkıcı fonksiyon: hisse silinince çağrılır
    ~StockNode() {
        std::cout << "[Cleanup] " << symbol << " destroyed.\n";
    }
};

int main() {
    // 🏗 4 adet hisse oluşturuluyor
    auto s1 = std::make_shared<StockNode>("AKBNK");
    auto s2 = std::make_shared<StockNode>("SISE");
    auto s3 = std::make_shared<StockNode>("FROTO");
    auto s4 = std::make_shared<StockNode>("THYAO");

    // 🔗 Zincir oluşturuluyor (tek yönlü bağlantı)
    s1->next = s2;
    std::cout << "[Link] 1" << s1->symbol << " → " << s2->symbol << " (next set)\n";
    s2->prev = s1;
    std::cout << "[Link] 2" << s2->symbol << " ← " << s1->symbol << " (prev set)\n";

    s2->next = s3;
    std::cout << "[Link] 3" << s2->symbol << " → " << s3->symbol << " (next set)\n";
    s3->prev = s1;
    std::cout << "[Link] 4" << s3->symbol << " ← " << s1->symbol << " (prev set)\n";

    s3->next = s4;
    std::cout << "[Link] 5" << s3->symbol << " → " << s4->symbol << " (next set)\n";
    s4->prev = s3;
    std::cout << "[Link] 6" << s4->symbol << " ← " << s3->symbol << " (prev set)\n";

    // 🔍 Kullanım sayısı kontrolü
    std::cout << "SISE use_count:  " << s2.use_count() << '\n';
    std::cout << "FROTO use_count: " << s3.use_count() << '\n';

    int total_refs = s1.use_count() + s2.use_count() + s3.use_count() + s4.use_count();
    std::cout << "Toplam shared_ptr referansı: " << total_refs << "\n";
}
