#include <iostream>
#include <string>
#include <chrono>
#include <ctime>
#include <sstream>

// Makro tanımları (preprocessor düzeyinde)
#define LOG_INFO(msg)    Logger::log(msg, LogLevel::INFO)
#define LOG_DEBUG(msg)   Logger::log(msg, LogLevel::DEBUG)
#define LOG_WARNING(msg) Logger::log(msg, LogLevel::WARNING)
#define LOG_ERROR(msg)   Logger::log(msg, LogLevel::ERROR)

enum class LogLevel { DEBUG, INFO, WARNING, ERROR };

class Logger {
public:
    static void log(const std::string& msg, LogLevel level = LogLevel::INFO) {
        std::cout << generateJson(level, msg) << std::endl;
    }

private:
    static std::string logLevelToString(LogLevel level) {
        switch (level) {
            case LogLevel::DEBUG: return "DEBUG";
            case LogLevel::INFO: return "INFO";
            case LogLevel::WARNING: return "WARNING";
            case LogLevel::ERROR: return "ERROR";
        }
        return "UNKNOWN";
    }

    static std::string currentTime() {
        auto now = std::chrono::system_clock::now();
        std::time_t tt = std::chrono::system_clock::to_time_t(now);
        std::tm* ptm = std::localtime(&tt);
        char buffer[32];
        std::strftime(buffer, 32, "%F %T", ptm);
        return buffer;
    }

    static std::string generateJson(LogLevel level, const std::string& msg) {
        std::ostringstream oss;
        oss << "{\"time\": \"" << currentTime()
            << "\", \"level\": \"" << logLevelToString(level)
            << "\", \"msg\": \"" << msg << "\"}";
        return oss.str();
    }
};

int main() {
    LOG_INFO("Uygulama başlatıldı");
    LOG_DEBUG("Veritabanı bağlantısı kuruldu");
    LOG_WARNING("Bellek kullanımı yüksek");
    LOG_ERROR("Disk yazma hatası!");
    return 0;
}
