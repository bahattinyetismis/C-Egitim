#include <iostream>
#include <unordered_map>
#include <string>

int main() {
// 📊 unordered_map: Hisse kodu → fiyat
std::unordered_map<std::string, double> fiyatlar;
// 🔧 Ekleme: insert
fiyatlar.insert({"AKBNK", 37.5});  // "AKBNK" anahtarı ve 37.5 değeri eklendi

// 🔧 Ekleme veya güncelleme: [] operatörü
fiyatlar["SISE"] = 51.9;            // Yoksa ekler, varsa günceller
fiyatlar["FROTO"] = 1020.1;
fiyatlar["THYAO"] = 310.7;

// 🔄 Güncelleme: [] ile değer değiştirme
fiyatlar["SISE"] = 52.3;            // "SISE" fiyatı güncellendi (51.9 → 52.3)

// 🔍 Erişim: at()
std::cout << "FROTO fiyatı: " << fiyatlar.at("FROTO") << " TL\n"; // Hata kontrolü içerir

// ❓ Varlık kontrolü: count() → 0 (yok) ya da 1 (var)
if (fiyatlar.count("VAKBN")) {
    std::cout << "VAKBN bulundu\n";
} else {
    std::cout << "VAKBN bulunamadı\n";
}

// 🔍 Bulma: find()
auto it = fiyatlar.find("THYAO");
if (it != fiyatlar.end()) {
    std::cout << "THYAO bulundu, fiyat: " << it->second << " TL\n";
}

// ❌ Silme: erase()
fiyatlar.erase("AKBNK"); // "AKBNK" silinir (varsa)

// 📏 Eleman sayısı: size()
std::cout << "Toplam eleman: " << fiyatlar.size() << "\n";

// 🔁 Gezinme: range-based for loop
std::cout << "\n📋 Tüm hisseler:\n";
for (const auto& [kod, fiyat] : fiyatlar) {
    std::cout << kod << ": " << fiyat << " TL\n";
}

// 🧼 Temizleme: clear()
fiyatlar.clear();
std::cout << "\nTemizlendi. Boş mu? " << (fiyatlar.empty() ? "Evet" : "Hayır") << "\n";

return 0;
}

