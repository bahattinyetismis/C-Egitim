#include <memory>     // shared_ptr ve weak_ptr için
#include <iostream>   // std::cout için
#include <string>     // std::string için
#include <vector>     // Hisse listesini tutmak için
#include <iomanip>    // setw için
#include <sstream>    // std::stringstream için

// 📦 Hisse senedi düğüm yapısı
struct StockNode {
    std::string symbol;                                // Hisse kodu (örnek: "AAPL")
    std::shared_ptr<StockNode> next;                   // Sonraki hisseye işaret eder
    std::weak_ptr<StockNode> prev;                     // Önceki hisseye işaret eder (zayıf referans)

    StockNode(const std::string& s) : symbol(s) {
        std::cout << "[Init] " << symbol << " created at address: " << this << "\n";
    }

    ~StockNode() {
        std::cout << "[Cleanup] " << symbol << " destroyed.\n";
    }

    void printDetails() const {
        std::cout << "\n🔍 Detaylı Hisse Bilgileri (" << symbol << "):\n";
        std::cout << std::string(50, '-') << "\n";
        std::cout << "📍 Bu hissenin adresi: " << this << "\n";
        std::cout << "➡️ Next pointer adresi: " << (next ? next.get() : nullptr) << "\n";
        std::cout << "⬅️ Prev pointer expired?: " << (prev.expired() ? "Evet" : "Hayır") << "\n";
        if (auto prevPtr = prev.lock()) {
            std::cout << "⬅️ Prev pointer adresi: " << prevPtr.get() << "\n";
        }
        std::cout << "🔢 Next shared_ptr use_count: " << (next ? next.use_count() : 0) << "\n";
        std::cout << "🔢 Prev weak_ptr use_count: " << prev.use_count() << "\n";
        std::cout << std::string(50, '-') << "\n";
    }
};

// Tablo şeklinde bağlantıları gösteren fonksiyon
void printLinkTable(const std::vector<std::shared_ptr<StockNode>>& hisseler) {
    std::cout << "\n📋 Hisse Senedi Bağlantı ve Adres Tablosu:\n";
    std::cout << std::string(160, '=') << "\n";
    std::cout << std::setw(40) << std::left << "PREV POINTER" 
              << std::setw(40) << "HİSSE KODU"
              << std::setw(40) << "NEXT POINTER"
              << std::setw(40) << "HİSSE ADRESİ" << "\n";
    std::cout << std::string(160, '-') << "\n";

    for (const auto& hisse : hisseler) {
        // Prev pointer bilgisi ve adresi
        std::string prevInfo = "nullptr";
        std::string prevAddr = "0x0";
        if (auto prev = hisse->prev.lock()) {
            prevInfo = prev->symbol;
            std::stringstream ss;
            ss << prev.get();
            prevAddr = ss.str();
            prevInfo += " (" + prevAddr + ")";
        }

        // Next pointer bilgisi ve adresi
        std::string nextInfo = "nullptr";
        std::string nextAddr = "0x0";
        if (hisse->next) {
            nextInfo = hisse->next->symbol;
            std::stringstream ss;
            ss << hisse->next.get();
            nextAddr = ss.str();
            nextInfo += " (" + nextAddr + ")";
        }

        // Hissenin kendi adresi
        std::stringstream ss;
        ss << hisse.get();
        std::string hisseAddr = ss.str();

        // Tablo satırını yazdır
        std::cout << std::setw(40) << std::left << prevInfo
                  << std::setw(40) << (hisse->symbol + " (" + hisseAddr + ")")
                  << std::setw(40) << nextInfo
                  << std::setw(40) << hisseAddr << "\n";
    }
    std::cout << std::string(160, '=') << "\n\n";
}

int main() {
    // 🏗 10 hisse oluşturuluyor
    std::vector<std::shared_ptr<StockNode>> hisseler;
    std::vector<std::string> isimler = {"AKBNK", "SISE", "FROTO", "THYAO", "ISCTR", "YKBNK", "KCHOL", "VAKBN", "TUPRS", "ASELS"};

    for (const auto& isim : isimler) {
        hisseler.push_back(std::make_shared<StockNode>(isim));
    }

    std::cout << "\n🔗 Zincir Bağlantıları Oluşturuluyor:\n";
    std::cout << std::string(100, '=') << "\n";
    
    // Önce tüm bağlantıları kur
    for (size_t i = 0; i < hisseler.size() - 1; ++i) {
        hisseler[i]->next = hisseler[i + 1];
        hisseler[i + 1]->prev = hisseler[i];
    }

    // Sonra bağlantı adreslerini yazdır
    for (size_t i = 0; i < hisseler.size() - 1; ++i) {
        std::stringstream ss_prev1, ss_next1, ss_prev2, ss_next2;
        ss_prev1 << (hisseler[i]->prev.lock() ? hisseler[i]->prev.lock().get() : nullptr);
        ss_next1 << (hisseler[i]->next ? hisseler[i]->next.get() : nullptr);
        ss_prev2 << (hisseler[i+1]->prev.lock() ? hisseler[i+1]->prev.lock().get() : nullptr);
        ss_next2 << (hisseler[i+1]->next ? hisseler[i+1]->next.get() : nullptr);

        std::cout << "[Link] prev[" << ss_prev1.str() << "] " << hisseler[i]->symbol << " next[" << ss_next1.str() << "] ";
        std::cout << "⇄ prev[" << ss_prev2.str() << "] " << hisseler[i+1]->symbol << " next[" << ss_next2.str() << "]\n";
    }
    std::cout << std::string(100, '=') << "\n\n";

    // Bağlantı tablosunu gösterme (kaldırıldı)

    std::cout << "\n📊 5. Hisseden 8. Hisseye İlerleme:\n";
    // 5. hisseden 8. hisseye git → indeks 4 → 7
    auto current = hisseler[4];
    for (int i = 0; i < 3; ++i) {
        std::cout << "İleri → " << current->symbol << "\n";
        if (current->next) current = current->next;
    }
    
    std::cout << "\n🎯 8. Hisse Detaylı Bilgileri:\n";
    current->printDetails();  // 8. hissenin detayları

    std::cout << "\n📊 8. Hisseden 3. Hisseye Geri Dönüş:\n";
    // 8. hisseden 3. hisseye geri git
    for (int i = 0; i < 4; ++i) {
        if (auto prev = current->prev.lock()) {
            current = prev;
            std::cout << "Geri → " << current->symbol << "\n";
        }
    }

    std::cout << "\n🎯 3. Hisse Detaylı Bilgileri:\n";
    current->printDetails();  // 3. hissenin detayları

    return 0;
} // 🧹 main bittiğinde tüm hisseler otomatik olarak yok edilir
