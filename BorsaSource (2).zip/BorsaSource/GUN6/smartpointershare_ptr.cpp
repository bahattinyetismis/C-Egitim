#include <memory>     // shared\_ptr ve weak\_ptr için
#include <iostream>   // std::cout için
#include <string>     // std::string için
#include <vector>     // Hisse listesini tutmak için

// 📦 Hisse senedi düğüm yapısı
struct StockNode {
std::string symbol;                                // Hisse kodu (örnek: "AAPL")
std::shared\_ptr<StockNode> next;                   // Sonraki hisseye işaret eder
std::weak\_ptr<StockNode> prev;                     // Önceki hisseye işaret eder (zayıf referans)

```
StockNode(const std::string& s) : symbol(s) {
    std::cout << "[Init] " << symbol << " created.\n";
}

~StockNode() {
    std::cout << "[Cleanup] " << symbol << " destroyed.\n";
}
```

};

int main() {
// 🏗 10 hisse oluşturuluyor
std::vector\<std::shared\_ptr<StockNode>> hisseler;
std::vector[std::string](std::string) isimler = {"AKBNK", "SISE", "FROTO", "THYAO", "ISCTR", "YKBNK", "KCHOL", "VAKBN", "TUPRS", "ASELS"};

```
for (const auto& isim : isimler) {
    hisseler.push_back(std::make_shared<StockNode>(isim));
}

// 🔗 Zincir bağlantıları (next ve prev)
for (size_t i = 0; i < hisseler.size() - 1; ++i) {
    hisseler[i]->next = hisseler[i + 1];
    hisseler[i + 1]->prev = hisseler[i];
    std::cout << "[Link] " << hisseler[i]->symbol << " ⇄ " << hisseler[i + 1]->symbol << "\n";
}

// 5. hisseden 8. hisseye git → indeks 4 → 7
auto current = hisseler[4];
for (int i = 0; i < 3; ++i) {
    if (current->next) current = current->next;
}
std::cout << "\n📌 8. Hisse: " << current->symbol << "\n";
std::cout << current->symbol << " use_count: " << current.use_count() << "\n";
std::cout << "prev expired? " << (current->prev.expired() ? "yes" : "no") << "\n";

// Buradan geriye 3. hisseye git (geri 4 adım) → indeks 7 → 4 → 3 → 2 → 1
for (int i = 0; i < 4; ++i) {
    if (auto prev = current->prev.lock()) {
        current = prev;
        std::cout << "Geriye geçildi → " << current->symbol << ", use_count: " << current.use_count() << ", prev expired? " << (current->prev.expired() ? "yes" : "no") << "\n";
    }
}
std::cout << "📌 3. Hisse: " << current->symbol << "\n";
std::cout << current->symbol << " use_count: " << current.use_count() << "\n";

// 🔎 Tüm hisselerin use_count değerleri
std::cout << "\n📊 Tüm use_count değerleri:\n";
for (const auto& hisse : hisseler) {
    std::cout << hisse->symbol << ": " << hisse.use_count()
              << ", prev expired? " << (hisse->prev.expired() ? "yes" : "no") << "\n";
}

return 0;
```

} // 🧹 main bittiğinde tüm hisseler otomatik olarak yok edilir
