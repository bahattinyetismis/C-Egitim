#include <memory>
#include <iostream>

struct Image { /* büyük veri yapısı */ };

// Görüntüyü görüntüleyen fonksiyon
void view(std::shared_ptr<Image> img) {
    std::cout << "use_count=" << img.use_count() << std::endl; // Kaç referans var?
}

int main() {
    auto img = std::make_shared<Image>(); // Tek tahsis: nesne + kontrol bloğu
    auto img2 = img;                      // Sayaç 2 olur
    view(img);                            // Sayaç 3 geçici olarak
    std::cout << "main count=" << img.use_count() << std::endl; // 2
} 
