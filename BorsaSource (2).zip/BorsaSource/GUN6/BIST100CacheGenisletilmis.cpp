#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <iomanip>

struct Stock {
    std::string code;
    std::string name;
    double price;
    long volume;
};

std::vector<Stock> loadStocksFromCSVFile(const std::string& filename) {
    std::vector<Stock> stocks;
    std::ifstream file(filename);
    std::string line;

    if (!file.is_open()) {
        std::cerr << "❌ Dosya açılamadı: " << filename << '\n';
        return stocks;
    }

    while (std::getline(file, line)) {
        std::stringstream ls(line);
        std::string code, name, priceStr, volumeStr;
        std::getline(ls, code, ',');
        std::getline(ls, name, ',');
        std::getline(ls, priceStr, ',');
        std::getline(ls, volumeStr, ',');

        try {
            stocks.push_back({code, name, std::stod(priceStr), std::stol(volumeStr)});
        } catch (...) {
            std::cerr << "⚠️ Satır hatalı: " << line << '\n';
        }
    }
    return stocks;
}

std::unordered_map<std::string, size_t> createMapIndex(const std::vector<Stock>& stocks) {
    std::unordered_map<std::string, size_t> indexMap;
    for (size_t i = 0; i < stocks.size(); ++i) {
        indexMap[stocks[i].code] = i;
    }
    return indexMap;
}

void printStocks(const std::string& title, const std::vector<Stock>& stocks) {
    std::cout << "🔎 " << title << " (" << stocks.size() << " sonuç):\n";
    for (const auto& stock : stocks) {
        std::cout << "  " << stock.code << " - " << stock.name
                  << " | Fiyat: " << stock.price << " | Hacim: " << stock.volume << '\n';
    }
    std::cout << '\n';
}

std::vector<Stock> getConsecutiveStocks(const std::vector<Stock>& stocks, size_t startIndex, int count) {
    std::vector<Stock> result;
    for (size_t i = startIndex; i < stocks.size() && result.size() < static_cast<size_t>(count); ++i) {
        result.push_back(stocks[i]);
    }
    return result;
}

int main() {
    std::string filename = "bist100.csv";
    auto stocks = loadStocksFromCSVFile(filename);
    if (stocks.empty()) {
        std::cerr << "⚠️ Hiç veri okunamadı. Program sonlandırılıyor.\n";
        return 1;
    }

    // Map içinde sadece index tutuyoruz
    auto stockIndexMap = createMapIndex(stocks);

    std::string hisseKodu;
    int count;

    std::cout << "🔤 Hisse kodu girin (örnek: AKBNK): ";
    std::cin >> hisseKodu;

    std::cout << "📊 Kaç adet hisse gösterilsin (başlangıç dahil): ";
    std::cin >> count;

    auto start = std::chrono::high_resolution_clock::now();
    auto it = stockIndexMap.find(hisseKodu);
    auto end = std::chrono::high_resolution_clock::now();
    auto durationMs = std::chrono::duration<double, std::milli>(end - start).count();

    if (it == stockIndexMap.end()) {
        std::cout << "❌ Hisse bulunamadı: " << hisseKodu << '\n';
        return 1;
    }

    size_t startIndex = it->second;
    auto result = getConsecutiveStocks(stocks, startIndex, count);

    printStocks("📋 Sonuçlar", result);
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "⏱ Index bulma süresi (unordered_map): " << durationMs << " ms\n";
}
