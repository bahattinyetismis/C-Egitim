#include <iostream>
#include <unordered_map>
#include <string>
#include <vector>
#include <thread>
#include <mutex>

// Her hisse için ayrı mutex'leri temsil eden map
std::unordered_map<std::string, std::mutex*> kilitler;
std::mutex global_mutex; // kilit map'ine erişimi korumak için

// Hisse kodu → fiyatlar vektörü
std::unordered_map<std::string, std::vector<double>> fiyatlar;

// Thread-safe fiyat ekleme fonksiyonu
auto fiyatEkle(const std::string& kod, double fiyat) {
    return std::thread([kod, fiyat]() {
        // Mutex map'ine erişimi sırala
        {
            std::scoped_lock lock(global_mutex);
            if (kilitler.find(kod) == kilitler.end()) {
                kilitler[kod] = new std::mutex();
            }
        }
        // Sadece o hisse için kilit al
        kilitler[kod]->lock();
        fiyatlar[kod].push_back(fiyat);
        std::cout << "[Thread] " << kod << " fiyat eklendi: " << fiyat << "\n";
        kilitler[kod]->unlock();
    });
}

int main() {
    // 4 farklı thread aynı anda farklı hisselere fiyat ekliyor
    std::thread t1 = fiyatEkle("AKBNK", 37.5);
    std::thread t2 = fiyatEkle("SISE", 51.9);
    std::thread t3 = fiyatEkle("FROTO", 1020.1);
    std::thread t4 = fiyatEkle("THYAO", 310.7);

    t1.join();
    t2.join();
    t3.join();
    t4.join();

    // Tüm fiyatları yaz
    std::cout << "\n📋 Tüm hisseler ve fiyat vektörleri:\n";
    for (const auto& [kod, fiyatvec] : fiyatlar) {
        std::cout << kod << ": ";
        for (double f : fiyatvec) std::cout << f << " ";
        std::cout << "\n";
    }

    // Temizleme
    for (auto& [kod, mtx] : kilitler) delete mtx;
    fiyatlar.clear();
    kilitler.clear();
    return 0;
}
