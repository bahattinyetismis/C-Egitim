#include <memory>
#include <iostream>

// Basit bir yapı tanımı
struct Widget {
    Widget() { std::puts("a"); }     // Oluşturucu
    ~Widget() { std::puts("z"); }    // Yıkıcı
};

// Sahipliği alıp işleyen fonksiyon
void process(std::unique_ptr<Widget> w) {
    // w burada geçici olarak Widget'e sahiptir
}

int main() {
    auto w = std::make_unique<Widget>(); // Widget nesnesi oluşturuluyor
    process(std::move(w));               // Sahiplik fonksiyona taşınıyor
    if (!w) std::puts("boş!");          // Artık w boş (null)
}
