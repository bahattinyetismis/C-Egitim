#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <algorithm>

// Makro: loglama
#define LOG(x) std::cout << "[LOG] " << x << std::endl

// Veri modeli
struct Stock {
    std::string symbol;       // Hisse kodu
    std::string name;         // Hisse adı
    double lastClosePrice;    // Son kapanış fiyatı
    long lastDayVolume;       // Son gün işlem hacmi
};

int main() {
    // Cache yapıları
    std::vector<std::shared_ptr<Stock>> stocks;  // Sıralı liste (index bazlı erişim)
    std::unordered_map<std::string, std::shared_ptr<Stock>> stockMap;  // Hızlı lookup

    // CSV dosyasından belleğe yükleme
    std::ifstream file("bist100.csv");
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string sym, name, priceStr, volStr;

        std::getline(iss, sym, ',');
        std::getline(iss, name, ',');
        std::getline(iss, priceStr, ',');
        std::getline(iss, volStr);

        auto stock = std::make_shared<Stock>(Stock{
            sym,
            name,
            std::stod(priceStr),
            std::stol(volStr)
        });

        stocks.push_back(stock);
        stockMap[sym] = stock;
    }
    file.close(); // Dosya yalnızca belleğe yüklemede kullanılır
    LOG("Tüm veriler belleğe alındı");

    // Kullanıcıdan hisse kodu al
    std::string query;
    std::cout << "Sorgulamak istediğiniz hisse kodunu girin: ";
    std::cin >> query;

    // Lambda ile cache üzerinden sorgulama
    auto showStock = [&](const std::string& code) {
        auto it = stockMap.find(code);
        if (it != stockMap.end()) {
            auto s = it->second;
            std::cout << "\n--- Hisse Bilgisi (Cache) ---\n";
            std::cout << "Kod: " << s->symbol << "\n";
            std::cout << "Ad : " << s->name << "\n";
            std::cout << "Kapanış: " << s->lastClosePrice << " TL\n";
            std::cout << "Hacim  : " << s->lastDayVolume << " lot\n";
        } else {
            std::cout << "Kod bulunamadı: " << code << std::endl;
        }
    };

    showStock(query);
}