#include <iostream>              // Giriş/çıkış işlemleri için gerekli
#include <memory>                // smart pointer'lar için gerekli (shared_ptr)

#define PRICE_THRESHOLD 200.0    // Fiyat karşılaştırmasında kullanılacak eşik değer
#define IS_EXPENSIVE(p) ((p) > PRICE_THRESHOLD) // Fiyat eşikten büyükse 'pahalı' kabul edilir
#define DEBUG_LOG(x) std::cout << "[DEBUG] " << x << '\n'

// Hisseyi temsil eden sınıf
class Stock {
public:
    std::string symbol;         // Hissenin sembolü (örneğin: AAPL)
    double price;               // Hissenin fiyatı

    // Kurucu fonksiyon
    Stock(std::string s, double p) : symbol(s), price(p) {}

    // Hisseyi ekrana yazdıran fonksiyon
    void print() const {
        std::cout << symbol << ": $" << price;               // Hisse bilgisi yazdır
        if (IS_EXPENSIVE(price)) std::cout << " Expensive!"; // Pahalıysa uyarı ver
        std::cout << '\n';                                   // Satır sonu
    }
};

int main() {
    // Hisse nesnesini shared_ptr ile oluştur
    std::shared_ptr<Stock> s = std::make_shared<Stock>("AAPL", 250);

    s->print();                        // Hisse detaylarını yazdır
    DEBUG_LOG("Kontrol tamamlandi."); // Debug log'u bas

    return 0;
}
