#include <iostream>
#include <memory>
#include <string>

// Soyut temel sınıf (interface gibi davranır)
class Stock {
public:
    virtual void info() = 0;           // Alt sınıfların uygulaması gereken fonksiyon
    virtual ~Stock() = default;        // Bellek sızıntısı önlemek için sanal yıkıcı
};

class SiseCam : public Stock {
public:
    void info() override {
        std::cout << "SISE: Şişecam hisse senedi.\n";
    }

    static std::unique_ptr<Stock> create() {
        return std::make_unique<SiseCam>();
    }
};

int main() {
    auto sise = SiseCam::create(); // Açıklama: Sınıf kendi üretim metodunu sağlar.
    sise->info();
    return 0;
}
