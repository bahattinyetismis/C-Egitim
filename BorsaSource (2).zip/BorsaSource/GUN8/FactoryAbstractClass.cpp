#include <iostream>
#include <memory>
#include <string>

// Soyut temel sınıf: Tüm hisselerin ortak arayüzü
class Stock {
public:
    virtual void info() = 0; // Her hisse info fonksiyonunu tanımlar
    virtual ~Stock() = default; // Polimorfik silme için sanal yıkıcı
};

// Hisse türleri: Sanayi ve Bankacılık
class IndustrialStock : public Stock {};
class BankingStock : public Stock {};

// Koç Holding (Sanayi hissesi)
class KCHOL : public IndustrialStock {
public:
    void info() override {
        std::cout << "KCHOL: Koç Holding sanayi sektöründedir.\n";
    }
};

// Yapı Kredi (Bankacılık hissesi)
class YKBNK : public BankingStock {
public:
    void info() override {
        std::cout << "YKBNK: Yapı Kredi banka sektöründedir.\n";
    }
};

// Soyut Factory arayüzü
class SectorStockFactory {
public:
    virtual std::unique_ptr<Stock> createLargeCap() = 0;
    virtual ~SectorStockFactory() = default;
};

// Somut Factory: Sanayi
class IndustrialStockFactory : public SectorStockFactory {
public:
    std::unique_ptr<Stock> createLargeCap() override {
        return std::make_unique<KCHOL>();
    }
};

// Somut Factory: Bankacılık
class BankingStockFactory : public SectorStockFactory {
public:
    std::unique_ptr<Stock> createLargeCap() override {
        return std::make_unique<YKBNK>();
    }
};

// Program girişi
int main() {
    // Bankacılık sektörüne ait factory seçiliyor
    std::unique_ptr<SectorStockFactory> factory = std::make_unique<BankingStockFactory>();

    // Factory üzerinden hisse oluşturuluyor
    auto hisse = factory->createLargeCap();

    // Hisse bilgisi yazdırılıyor
    hisse->info();

    return 0;
}

