#include <iostream>     // std::cout
#include <memory>       // std::unique_ptr
#include <string>       // std::string

// Soyut temel sınıf — tüm hisseler bundan türeyecek
class Stock {
public:
    virtual void info() = 0;               // Alt sınıflar tarafından override edilir
    virtual ~Stock() = default;            // Sanal yıkıcı — belleği güvenli temizlemek için
};

// Somut hisse sınıfları
class Akbank : public Stock {
public:
    void info() override {
        std::cout << "AKBNK: Akbank hisse senedi.\n";
    }
};

class Garanti : public Stock {
public:
    void info() override {
        std::cout << "GARAN: Garanti BBVA hisse senedi.\n";
    }
};

// Singleton Factory — uygulama boyunca yalnızca bir örneği olur
class SingletonFactory {
    SingletonFactory() = default; // Dışarıdan oluşturulamaz

public:
    // Factory'nin tek örneğini döner
    static SingletonFactory& instance() {
        static SingletonFactory f; // C++11 sonrası thread-safe singleton
        return f;
    }

    // Hisse koduna göre uygun nesneyi üretir
    std::unique_ptr<Stock> create(const std::string& code) {
        if (code == "AKBNK") return std::make_unique<Akbank>();
        else if (code == "GARAN") return std::make_unique<Garanti>();
        return nullptr; // Tanımsız kod için null döner
    }
};

int main() {
    // Singleton instance'a erişilir
    auto& factory = SingletonFactory::instance();

    // Hisse üretimi yapılır
    auto hisse = factory.create("AKBNK");

    // Hisse bilgisi yazdırılır
    if (hisse) hisse->info();

    return 0;

}
