#include <iostream>
#include <memory>
#include <string>

// Soyut temel sınıf
class Stock {
public:
    virtual void info() = 0;
    virtual ~Stock() = default;
};

// SiseCam
class SiseCam : public Stock {
public:
    void info() override {
        std::cout << "SISE: Şişecam hisse senedi.\n";
    }
};

int main() {
    std::unique_ptr<Stock> sise = std::make_unique<SiseCam>();
    sise->info();
    return 0;
} 