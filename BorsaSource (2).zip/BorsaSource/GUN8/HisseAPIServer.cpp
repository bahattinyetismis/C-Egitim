// Tek parça çalışan HTTP sunucu (cpp-httplib & nlohmann/json)
#include "include/httplib.h"               // HTTP sunucusu ve istemcisi için tek başına header
#include "include/json.hpp"       // JSON parse ve oluşturma
#include <fstream>                 // Dosyaya yazmak için
#include <iostream>                // Konsol çıktısı için
#include <unordered_map>          // Kayıtlı hisse haritası için
#include <memory>                 // unique_ptr için

// === Temel Stock Arayüzü ===
class Stock {
public:
    virtual ~Stock() = default;                             // Sanal yıkıcı
    virtual std::string kod() const = 0;                    // Hisse kodu
    virtual std::string adi() const = 0;                    // Hisse adı
    virtual std::string sektor() const = 0;                 // Sektör adı
};

// === Hisse Sınıfı ===
class SanayiHissesi : public Stock {
public:
    std::string kodu, adi_; double fiyat_{};                // Hisse bilgileri
    std::string kod() const override { return kodu; }       // Kod döndür
    std::string adi() const override { return adi_; }       // Ad döndür
    std::string sektor() const override { return "Sanayi"; } // Sektör döndür
};

// === Registry Factory ===
class RegistryFactory {
    using Creator = std::function<std::unique_ptr<Stock>()>;       // Oluşturucu fonksiyon tipi
    std::unordered_map<std::string, Creator> registry;             // Hisse kodu → üretici fonksiyon
public:
    void registerStock(const std::string& kod, Creator c) {        // Yeni hisse türü kaydet
        registry[kod] = c;
    }
    std::unique_ptr<Stock> create(const std::string& kod) {        // Hisse koduna göre nesne üret
        if (registry.count(kod)) return registry[kod]();
        return nullptr;
    }
};

int main() {
    RegistryFactory factory;                                       // Factory nesnesi
    factory.registerStock("THYAO", [] {                           // THYAO için üretici fonksiyon
        auto h = std::make_unique<SanayiHissesi>();
        h->kodu = "THYAO";
        h->adi_ = "Türk Hava Yolları";
        return h;
    });

    httplib::Server svr;                                           // HTTP sunucusu başlatılır

    svr.Post("/api/istek", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            nlohmann::json j = nlohmann::json::parse(req.body);    // JSON gövdesini ayrıştır
            std::string kod = j.at("hisseKodu");
            double fiyat = j.at("fiyat");
            int adet = j.value("adet", 0);                         // Varsayılan: 0
            std::string islem = j.value("islem", "BELİRSİZ");     // Varsayılan: BELİRSİZ
            std::string kurum = j.value("araciKurum", "UNKNOWN"); // Varsayılan: UNKNOWN
            std::string zaman = j.value("zaman", "");

            auto hisse = factory.create(kod);                       // Hisse üret
            if (!hisse) {
                res.status = 404;                                   // Tanımsız hisse hatası
                res.set_content("{\"error\":\"Tanımsız hisse kodu\"}", "application/json");
                return;
            }

            // JSON olarak logla
            nlohmann::json log = {
                {"kod", kod},
                {"fiyat", fiyat},
                {"adet", adet},
                {"islem", islem},
                {"araciKurum", kurum},
                {"zaman", zaman}
            };

            std::ofstream ofs("emir_data.json", std::ios::app);   // JSON dosyasına ekle
            ofs << log.dump() << std::endl;

            std::cout << "Yeni emir işlendi: " << log.dump() << "\n"; // Konsola yaz
            res.set_content("{\"status\":\"OK\"}", "application/json"); // Başarı yanıtı
        } catch (const std::exception& e) {
            res.status = 400;                                       // JSON hatası
            res.set_content(std::string("{\"error\":\"") + e.what() + "\"}", "application/json");
        }
    });

    std::cout << "Emir sunucusu başlatıldı: http://localhost:8080\n"; // Bilgilendirme
    svr.listen("0.0.0.0", 8080);                                   // Sunucuyu başlat
    return 0;
}
