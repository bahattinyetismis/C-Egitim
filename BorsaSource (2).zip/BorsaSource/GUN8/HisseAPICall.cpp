#include "include/httplib.h"
#include "include/json.hpp"
#include <iostream>

int main() {
    // Sunucu adresi ve port
    httplib::Client cli("http://localhost:8080");

    // Emir verisi (örnek: THYAO hisse için alım talebi)
    nlohmann::json emir = {
        {"hisseKodu", "THYAO"},
        {"fiyat", 310.7},
        {"adet", 1000},
        {"islem", "AL"},  // AL veya SAT
        {"araciKurum", "ISYAT"},
        {"zaman", "2025-06-25T10:12:00"}
    };

    // JSON string olarak dönüştür ve gönder
    auto res = cli.Post("/api/istek", emir.dump(), "application/json");

    if (res && res->status == 200) {
        std::cout << "Emir başarıyla gönderildi. Sunucu cevabı: " << res->body << std::endl;
    } else {
        std::cerr << "Emir gönderilemedi. Hata!" << std::endl;
    }

    return 0;
}
