#include <iostream>
#include <memory>
#include <string>

// Soyut temel sınıf
class Stock {
public:
    virtual void info() = 0;
    virtual ~Stock() = default;
};

// Akbank
class Akbank : public Stock {
public:
    void info() override {
        std::cout << "AKBNK: Akbank hisse senedi.\n";
    }
};

// Garanti
class Garanti : public Stock {
public:
    void info() override {
        std::cout << "GARAN: Garanti BBVA hisse senedi.\n";
    }
};

// SiseCam
class SiseCam : public Stock {
public:
    void info() override {
        std::cout << "SISE: Şişecam hisse senedi.\n";
    }

    static std::unique_ptr<Stock> create() {
        return std::make_unique<SiseCam>();
    }
};

int main() {
    std::string code = "AKBNK";

    std::unique_ptr<Stock> hisse;

    if (code == "AKBNK") {
        hisse = std::make_unique<Akbank>();
    }
    else if (code == "GARAN") {
        hisse = std::make_unique<Garanti>();
    }
    else {
        std::cout << "Bilinmeyen hisse kodu: " << code << "\n";
        return 1;
    }

    hisse->info(); // Çıktı: AKBNK: Akbank hisse senedi.

    auto sise = SiseCam::create(); // Açıklama: Sınıf kendi üretim metodunu sağlar.
    sise->info();

    return 0;
}
