#include <iostream>     // std::cout
#include <memory>       // std::unique_ptr
#include <string>       // std::string
#include <map>          // std::map
#include <functional>   // std::function

// Soyut hisse sınıfı
class Stock {
public:
    virtual void info() = 0;
    virtual ~Stock() = default;
};

// Somut hisse sınıfları
class Akbank : public Stock {
public:
    void info() override {
        std::cout << "AKBNK: Akbank hisse senedi.\n";
    }
};

class Garanti : public Stock {
public:
    void info() override {
        std::cout << "GARAN: Garanti BBVA hisse senedi.\n";
    }
};

// Registry Factory sınıfı
class RegistryFactory {
    // Creator = Hisse nesnesi üretecek fonksiyon tipi
    using Creator = std::function<std::unique_ptr<Stock>()>;

    // Hisse kodu → oluşturucu fonksiyon haritası
    std::map<std::string, Creator> registry;

public:
    // Yeni hisse sınıfı kaydeder
    void registerStock(const std::string& code, Creator creator) {
        registry[code] = creator;
    }

    // Koddan uygun hisseyi oluşturur
    std::unique_ptr<Stock> create(const std::string& code) {
        if (registry.count(code)) return registry[code]();
        return nullptr;
    }
};

int main() {
    RegistryFactory factory;

    // AKBNK ve GARAN için üretici fonksiyonlar kaydediliyor (lambda fonksiyonlar)
    factory.registerStock("AKBNK", [] { return std::make_unique<Akbank>(); });
    factory.registerStock("GARAN", [] { return std::make_unique<Garanti>(); });

    // İstediğimiz hisseyi yarat
    auto hisse = factory.create("GARAN");

    // info() çağrılarak hisse bilgisi yazdırılır
    if (hisse) hisse->info();

    return 0;
}
