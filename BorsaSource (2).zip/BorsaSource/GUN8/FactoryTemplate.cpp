#include <iostream>     // std::cout için
#include <memory>       // std::unique_ptr için
#include <string>       // std::string için

// Soyut temel sınıf
class Stock {
public:
    virtual void info() = 0;               // Alt sınıflar tarafından override edilecek fonksiyon
    virtual ~Stock() = default;            // Bellek sızıntısını önlemek için sanal yıkıcı
};

// Somut hisse sınıfı: Akbank
class Akbank : public Stock {
public:
    void info() override {
        std::cout << "AKBNK: Akbank hisse senedi.\n";
    }
};

// Şablon tabanlı factory sınıfı
template <typename T>
class TemplateFactory {
public:
    static std::unique_ptr<Stock> create() {
        return std::make_unique<T>();      // Tür parametresiyle nesne oluşturulur
    }
};

int main() {
    // Derleme zamanında tür belirlenerek factory çağrılır
    auto hisse = TemplateFactory<Akbank>::create();

    // Polimorfik olarak info() fonksiyonu çağrılır
    hisse->info();

    return 0;
}
