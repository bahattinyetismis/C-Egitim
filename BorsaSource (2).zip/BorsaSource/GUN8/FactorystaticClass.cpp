#include <iostream>
#include <memory>
#include <string>

// Soyut temel sınıf (interface gibi davranır)
class Stock {
public:
    virtual void info() = 0;           // Alt sınıfların uygulaması gereken fonksiyon
    virtual ~Stock() = default;        // Bellek sızıntısı önlemek için sanal yıkıcı
};

// SiseCam sınıfı — Şişecam hissesi
class SiseCam : public Stock {
public:
    // Hisse bilgisi veren fonksiyon
    void info() override {
        std::cout << "SISE: Şişecam hisse senedi.\n";
    }
};

// Uygulama başlangıç noktası
int main() {
    // Factory metod kullanmadan doğrudan oluşturuluyor
    std::unique_ptr<Stock> sise = std::make_unique<SiseCam>();
    
    // Hisse bilgisi yazdırılıyor
    sise->info();

    return 0;
}