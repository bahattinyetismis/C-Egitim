#include <iostream>     // std::cout
#include <memory>       // std::unique_ptr

// Soyut temel sınıf — tüm hisseler buradan türeyecek
class Stock {
public:
    virtual void info() = 0;               // Alt sınıflar tarafından override edilir
    virtual ~Stock() = default;            // Bellek sızıntısı önlemek için sanal yıkıcı
};

// Hisse aileleri (sanayi ve bankacılık)
class IndustrialStock : public Stock {};   // Sanayi hisseleri için taban sınıf
class BankingStock : public Stock {};      // Bankacılık hisseleri için taban sınıf

// Somut hisse sınıfları
class KCHOL : public IndustrialStock {
public:
    void info() override {
        std::cout << "KCHOL: Koç Holding sanayi sektöründedir.\n";
    }
};

class YKBNK : public BankingStock {
public:
    void info() override {
        std::cout << "YKBNK: Yapı Kredi banka sektöründedir.\n";
    }
};

// Soyut factory — ortak arayüz sağlar
class SectorStockFactory {
public:
    virtual std::unique_ptr<Stock> createLargeCap() = 0; // Hisse üretimi için arayüz
    virtual ~SectorStockFactory() = default;
};

// Sanayi hisseleri için somut factory
class IndustrialStockFactory : public SectorStockFactory {
public:
    std::unique_ptr<Stock> createLargeCap() override {
        return std::make_unique<KCHOL>();  // Sanayi sektöründen büyük hisse döndür
    }
};

// Bankacılık hisseleri için somut factory
class BankingStockFactory : public SectorStockFactory {
public:
    std::unique_ptr<Stock> createLargeCap() override {
        return std::make_unique<YKBNK>();  // Bankacılık sektöründen büyük hisse döndür
    }
};

// Ana fonksiyon — uygulama buradan başlar
int main() {
    // Soyut factory tipiyle factory seçimi yapılır
    std::unique_ptr<SectorStockFactory> factory = std::make_unique<BankingStockFactory>();

    // Seçilen factory üzerinden hisse oluşturulur
    auto hisse = factory->createLargeCap();

    // Hisse bilgisi yazdırılır (polimorfik çağrı)
    hisse->info();

    return 0;
}
