#include <iostream>     // std::cout için
#include <memory>       // std::unique_ptr için
#include <string>       // std::string için

// Soyut temel sınıf — tüm hisseler bu sınıftan türeyecek
class Stock {
public:
    virtual void info() = 0;               // Alt sınıfların override etmesi gereken fonksiyon
    virtual ~Stock() = default;            // Sanal yıkıcı — belleği güvenli şekilde temizler
};

// Parametre ile hisse bilgisi taşıyan sınıf
class CustomStock : public Stock {
    std::string code;      // Hisse kodu (ör: THYAO)
    std::string company;   // Şirket adı
    double price;          // Hisse fiyatı

public:
    // Yapıcı metod — kod, şirket adı ve fiyat alınır
    CustomStock(std::string c, std::string comp, double p)
        : code(c), company(comp), price(p) {}

    // Hisse bilgisi yazdırma
    void info() override {
        std::cout << code << ": " << company << ", fiyat: " << price << "\n";
    }
};

// Parametrik factory — dışarıdan veri alarak hisse üretir
class ParametricFactory {
public:
    // Verilen bilgilerle bir CustomStock üretip döner
    static std::unique_ptr<Stock> create(const std::string& code, const std::string& company, double price) {
        return std::make_unique<CustomStock>(code, company, price);
    }
};

int main() {
    // Parametre ile THYAO hissesi üretiliyor
    auto hisse = ParametricFactory::create("THYAO", "Türk Hava Yolları", 310.7);

    // Üretilen hissenin bilgisi yazdırılıyor
    hisse->info();

    return 0;
}
