#include <iostream>
#include <memory>
#include <string>

class Stock {
public:
    virtual void info() = 0;
};

class Akbank : public Stock {
public:
    void info() override {
        std::cout << "AKBNK: Akbank hisse senedi.\n";
    }
};

class Garanti : public Stock {
public:
    void info() override {
        std::cout << "GARAN: Garanti BBVA hisse senedi.\n";
    }
};

class StockFactory {
public:
    static std::unique_ptr<Stock> createStock(const std::string& code) {
        if (code == "AKBNK") return std::make_unique<Akbank>();
        else if (code == "GARAN") return std::make_unique<Garanti>();
        return nullptr;
    }
};

int main() {
    auto hisse = StockFactory::createStock("AKBNK");
    hisse->info(); // Açıklama: Factory AKBNK için ilgili sınıfı döner.
}
