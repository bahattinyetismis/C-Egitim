#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <stdexcept>
#include <iomanip>
#include <algorithm>

// 🌐 Global mutex – log ve dosya yazımı için
std::mutex ioMutex;

// 📁 RAII: CSV'yi satır satır okuyup memory'ye yükleyen sınıf
class CSVReader {
    std::ifstream inFile;
public:
    CSVReader(const std::string& path) {
        inFile.open(path);
        if (!inFile.is_open())
            throw std::runtime_error("CSV açılamadı: " + path);
    }
    ~CSVReader() {
        if (inFile.is_open()) inFile.close();
    }
    bool readLine(std::string& line) {
        return static_cast<bool>(std::getline(inFile, line));
    }
};

// 🗃️ Veri deposu tipimiz: kod → fiyat
using StockMap = std::unordered_map<std::string, double>;
using StockVec = std::vector<std::pair<std::string, double>>;

// 💾 Memory'ye yükle
StockMap loadToMemory(const std::string& csvPath) {
    CSVReader reader(csvPath);
    std::string line;

    // Başlığı atla
    reader.readLine(line);

    StockMap m;
    while (reader.readLine(line)) {
        std::stringstream ss(line);
        std::string kod, ad, fiyatStr, hacim, sektor;

        std::getline(ss, kod, ',');
        std::getline(ss, ad, ',');
        std::getline(ss, fiyatStr, ',');
        std::getline(ss, hacim, ',');
        std::getline(ss, sektor, ',');

        double fiyat = std::stod(fiyatStr);
        m[kod] = fiyat;
    }

    // 🖨️ Terminale yaz
    {
        std::lock_guard<std::mutex> lk(ioMutex);
        std::cout << "Unordered_map memory'de yüklendi. Toplam hisse: " << m.size() << "\n";
    }

    return m;
}

// Sıralı vektöre dönüştür
StockVec mapToVec(const StockMap& m) {
    StockVec v(m.begin(), m.end());
    std::sort(v.begin(), v.end(), [](const auto& a, const auto& b) {
        return a.first < b.first;
    });
    return v;
}

// 🔧 Fiyat güncelleme: 70'in altındaysa +5
void adjustPrices(StockMap& m) {
    for (auto& [kod, fiyat] : m) {
        if (fiyat < 70.0) {
            fiyat += 5.0;
        }
    }
}

// 🧵 Thread fonksiyonu: belirli aralıktaki öğeleri dosyaya yaz
void writeRange(const StockVec& v, size_t start, size_t end, int threadIndex) {
    size_t fileStart = start + 1;
    size_t fileEnd = end;
    std::string filename = "hisse" + std::to_string(fileStart) + "-" + std::to_string(fileEnd) + ".txt";
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::lock_guard<std::mutex> lk(ioMutex);
        std::cerr << "Dosya açılamadı: " << filename << "\n";
        return;
    }

    outFile << std::fixed << std::setprecision(2);
    for (size_t idx = start; idx < end && idx < v.size(); ++idx) {
        outFile << v[idx].first << " | " << v[idx].second << " TL\n";
    }

    {
        std::lock_guard<std::mutex> lk(ioMutex);
        std::cout << filename << " yazıldı (" << start << "-" << end-1 << ").\n";
    }
}

int main() {
    try {
        // 1️⃣ CSV'yi memory'ye yükle
        StockMap m = loadToMemory("C:/BorsaSource/MVP/BIST100_Verileri.csv");

        // 2️⃣ Fiyatları güncelle
        adjustPrices(m);

        // 3️⃣ Sıralı vektöre aktar
        StockVec v = mapToVec(m);

        // 4️⃣ 10'luk dosyalara böl ve paralel yaz
        size_t n = v.size();
        size_t chunkSize = 10;
        size_t numFiles = (n + chunkSize - 1) / chunkSize;

        std::vector<std::thread> threads;
        for (size_t i = 0; i < numFiles; ++i) {
            size_t start = i * chunkSize;
            size_t end = std::min(start + chunkSize, n);
            threads.emplace_back(writeRange, std::cref(v), start, end, static_cast<int>(i));
        }

        for (auto& t : threads) t.join();

        std::cout << "Tüm dosyalar yazıldı.\n";
    }
    catch (const std::exception& ex) {
        std::cerr << "HATA: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
