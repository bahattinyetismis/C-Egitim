// 📂 Gerekli başlık dosyaları
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <stdexcept>
#include <iomanip>
#include <chrono>
#include <thread>

// 🌐 Global mutex – log ve dosya yazımı için
std::mutex ioMutex;

// 📁 RAII: CSV'yi satır satır okuyup memory'ye yükleyen sınıf
class CSVReader {
    std::ifstream inFile;
public:
    CSVReader(const std::string& path) {
        inFile.open(path);
        if (!inFile.is_open())
            throw std::runtime_error("CSV açılamadı: " + path);
    }
    ~CSVReader() {
        if (inFile.is_open()) inFile.close();
    }
    bool readLine(std::string& line) {
        return static_cast<bool>(std::getline(inFile, line));
    }
};

// 🧾 Tek bir hisse kaydı
struct Hisse {
    std::string kod;
    std::string ad;
    double fiyat;
    std::string hacim;
    std::string sektor;
};

// 📦 Belleğe unordered_map olarak yükleme
std::unordered_map<std::string, Hisse> loadStocks(const std::string& csvPath, std::vector<std::string>& kodSirasi) {
    CSVReader reader(csvPath);
    std::string line;
    reader.readLine(line);  // Başlık atla

    std::unordered_map<std::string, Hisse> hisseMap;
    while (reader.readLine(line)) {
        std::stringstream ss(line);
        std::string kod, ad, fiyatStr, hacim, sektor;
        std::getline(ss, kod, ',');
        std::getline(ss, ad, ',');
        std::getline(ss, fiyatStr, ',');
        std::getline(ss, hacim, ',');
        std::getline(ss, sektor, ',');

        double fiyat = std::stod(fiyatStr);
        hisseMap[kod] = {kod, ad, fiyat, hacim, sektor};
        kodSirasi.push_back(kod);
    }
    {
        std::lock_guard<std::mutex> lk(ioMutex);
        std::cout << hisseMap.size() << " hisse memory'e yüklendi.\n";
    }
    return hisseMap;
}

// 🔧 Fiyat güncelleme: sadece 71–79. sıradaki hisseler 5 TL artar
void adjustPrices(std::unordered_map<std::string, Hisse>& hisseler, const std::vector<std::string>& kodSirasi) {
    for (size_t i = 71; i <= 79 && i < kodSirasi.size(); ++i) {
        hisseler[kodSirasi[i]].fiyat += 5.0;
    }
}

// 🧵 Yeni thread fonksiyonu: belirli hisseleri yaz
void writeToFileNamed(const std::unordered_map<std::string, Hisse>& hisseler, const std::vector<std::string>& kodlar, const std::string& filename) {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::lock_guard<std::mutex> lk(ioMutex);
        std::cerr << "Dosya açılamadı: " << filename << "\n";
        return;
    }

    outFile << "kod,ad,fiyat,hacim,sektor\n";
    outFile << std::fixed << std::setprecision(2);
    for (const std::string& kod : kodlar) {
        const auto& h = hisseler.at(kod);
        outFile << h.kod << "," << h.ad << "," << h.fiyat << "," << h.hacim << "," << h.sektor << "\n";
    }

    std::lock_guard<std::mutex> lk(ioMutex);
    std::cout << filename << " yazıldı (" << kodlar.size() << " hisse).\n";
}

// 🚀 Ana fonksiyon
int main() {
    try {
        std::vector<std::string> kodSirasi;
        auto hisseler = loadStocks("C:/BorsaSource/MVP/BIST100_Verileri.csv", kodSirasi);

        std::this_thread::sleep_for(std::chrono::seconds(10));
        adjustPrices(hisseler, kodSirasi);

        std::vector<std::thread> threads;

        for (size_t i = 0; i < kodSirasi.size(); i += 10) {
            std::vector<std::string> grup;
            for (size_t j = i; j < i + 10 && j < kodSirasi.size(); ++j) {
                grup.push_back(kodSirasi[j]);
            }
            std::string dosyaAdi = "hisse" + std::to_string((int)i) + std::to_string((int)i + 9) + ".csv";
            threads.emplace_back(writeToFileNamed, std::cref(hisseler), grup, dosyaAdi);
        }

        for (auto& t : threads) t.join();
        std::cout << "Tüm dosyalar yazıldı.\n";
    } catch (const std::exception& ex) {
        std::cerr << "HATA: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
