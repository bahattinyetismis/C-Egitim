#include <iostream>
#include <hiredis/hiredis.h>
#include <mysql.h>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

int main() {
    redisContext* redis = redisConnect("127.0.0.1", 6379);
    if (!redis || redis->err) {
        std::cerr << "[REDIS] Bağlantı hatası\n";
        return 1;
    }

    MYSQL* conn = mysql_init(NULL);
    mysql_real_connect(conn, "localhost", "root", "Stock1!2345", "emir_db", 3306, NULL, 0);

    for (int id = 1; id <= 100; ++id) {  // örnek olarak 100 ID'ye kadar kontrol
        std::string key = "emir:" + std::to_string(id);
        redisReply* reply = (redisReply*)redisCommand(redis, "GET %s", key.c_str());
        if (reply->type == REDIS_REPLY_NIL) {
            freeReplyObject(reply);
            continue;  // kayıt yok
        }

        json emir = json::parse(reply->str);
        freeReplyObject(reply);

        char query[512];
        snprintf(query, sizeof(query),
            "INSERT INTO emirler (id, kod, fiyat, adet, islem, kurum, zaman, statu) VALUES (%d, '%s', %.2f, %d, '%s', '%s', '%s', '%s')",
            emir["id"].get<int>(),
            emir["kod"].get<std::string>().c_str(),
            emir["fiyat"].get<double>(),
            emir["adet"].get<int>(),
            emir["islem"].get<std::string>().c_str(),
            emir["kurum"].get<std::string>().c_str(),
            emir["zaman"].get<std::string>().c_str(),
            emir["statu"].get<std::string>().c_str()
        );

        if (mysql_query(conn, query) != 0) {
            std::cerr << "[MYSQL] Hata: " << mysql_error(conn) << "\n";
        } else {
            std::cout << "[MYSQL] Kaydedildi: id=" << emir["id"] << "\n";
        }
    }

    mysql_close(conn);
    redisFree(redis);
    return 0;
}
