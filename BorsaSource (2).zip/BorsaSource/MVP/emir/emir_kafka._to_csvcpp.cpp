#include <mysql.h>
#include <librdkafka/rdkafkacpp.h>
#include <iostream>
#include <sstream>
#include <memory>
#include <incliude/json/json.h>  // Requires `jsoncpp` library

void sendToKafka(const std::string& msg) {
    std::string errstr;
    RdKafka::Conf *conf = RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL);
    conf->set("bootstrap.servers", "localhost:9092", errstr);
    std::unique_ptr<RdKafka::Producer> producer(RdKafka::Producer::create(conf, errstr));
    if (!producer) {
        std::cerr << "Kafka üretici oluşturulamadı: " << errstr << "\n";
        return;
    }
    producer->produce("emir_topic", RdKafka::Topic::PARTITION_UA,
                      RdKafka::Producer::RK_MSG_COPY,
                      const_cast<char*>(msg.c_str()), msg.size(),
                      nullptr, nullptr);
    producer->flush(5000);
}

int main() {
    MYSQL* conn = mysql_init(NULL);
    mysql_real_connect(conn, "localhost", "root", "Stock1!2345", "emir_db", 3306, NULL, 0);

    MYSQL_RES* res;
    MYSQL_ROW row;

    mysql_query(conn, "SELECT * FROM emirler");
    res = mysql_store_result(conn);

    MYSQL_FIELD* fields = mysql_fetch_fields(res);
    int numFields = mysql_num_fields(res);

    while ((row = mysql_fetch_row(res))) {
        Json::Value jsonRow;
        for (int i = 0; i < numFields; ++i) {
            std::string key = fields[i].name;
            jsonRow[key] = row[i] ? row[i] : "";
        }
        Json::StreamWriterBuilder writer;
        std::string msg = Json::writeString(writer, jsonRow);
        sendToKafka(msg);
    }

    mysql_free_result(res);
    mysql_close(conn);
    std::cout << "[Producer] Veriler Kafka'ya gönderildi.\n";
    return 0;
}
