// === emir_client.cpp ===
#include "httplib.h"            // HTTP istemcisi
#include "json.hpp"              // JSON işleme
#include <fstream>               // Dosya okuma/yazma
#include <iostream>
#include <vector>

using json = nlohmann::json;

int main() {
    httplib::Client cli("localhost", 8099);

    // emirler.json dosyasını oku
    std::ifstream ifs("emirler.json");
    if (!ifs.is_open()) {
        std::cerr << "[HATA] emirler.json dosyası açılamadı\n";
        return 1;
    }

    json emirListesi;
    try {
        ifs >> emirListesi;
    } catch (const std::exception& e) {
        std::cerr << "[HATA] JSON ayrıştırılamadı: " << e.what() << "\n";
        return 1;
    }

    std::ofstream ofs("gonderilen_emirler.jsonl", std::ios::app);

    for (auto emir : emirListesi) {
        // İlk gönderimde statü 'B'ekleyen olarak işaretlenir
        emir["statu"] = "B";

        auto res = cli.Post("/api/istek", emir.dump(), "application/json");
        if (res && res->status == 200) {
            std::cout << "[OK] Emir gönderildi: " << emir.dump() << "\n";
            ofs << emir.dump() << "\n";
        } else {
            std::cerr << "[HATA] Emir gönderilemedi: " << emir.dump() << "\n";
        }
    }

    std::cout << "[TAMAMLANDI] Tüm emirler işlendi.\n";
    return 0;
}