// === emir_json_to_mysql.cpp ===
#include  <mysql.h>
#include <fstream>
#include <iostream>

#include <string>
#include "include/json.hpp"     // nlohmann::json

using json = nlohmann::json;

// Emirleri veritabanına yazan fonksiyon
void insertToMySQL(const json& e) {
    MYSQL* conn = mysql_init(NULL);
    if (!mysql_real_connect(conn, "localhost", "root", "Stock1!2345", "emir_db", 3306, NULL, 0)) {
        std::cerr << "[MYSQL] Bağlantı hatası: " << mysql_error(conn) << "\n";
        return;
    }

    char query[512];
    snprintf(query, sizeof(query),
             "INSERT INTO emirler (kod, fiyat, adet, islem, kurum, zaman, statu) VALUES ('%s', %.2f, %d, '%s', '%s', '%s', '%c')",
             e["hisseKodu"].get<std::string>().c_str(),
             e["fiyat"].get<double>(),
             e["adet"].get<int>(),
             e.value("islem", "BELIRSIZ").c_str(),
             e.value("araciKurum", "UNKNOWN").c_str(),
             e.value("zaman", "").c_str(),
             'B'); // Başlangıçta tüm emirler Bekleyen durumunda

    if (mysql_query(conn, query)) {
        std::cerr << "[MYSQL] INSERT hatası: " << mysql_error(conn) << "\n";
    }
    mysql_close(conn);
}

int main() {
    std::ifstream f("emirler.json");
    if (!f.is_open()) {
        std::cerr << "[HATA] emirler.json dosyası açılamadı!\n";
        return 1;
    }

    json data;
    try {
        f >> data;
    } catch (const std::exception& e) {
        std::cerr << "[HATA] JSON parse hatası: " << e.what() << "\n";
        return 1;
    }

    if (!data.is_array()) {
        std::cerr << "[HATA] Beklenen JSON dizi formatı!\n";
        return 1;
    }

    for (const auto& emir : data) {
        insertToMySQL(emir);
    }

    std::cout << "[INFO] Tüm emirler veritabanına aktarıldı.\n";
    return 0;
}

