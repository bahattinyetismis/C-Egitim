// connection_pool.h
#pragma once
#include <queue>
#include <mutex>
#include <condition_variable>
#include <mysql.h>

class ConnectionPool {
private:
    std::queue<MYSQL*> pool;
    std::mutex mtx;
    std::condition_variable cv;
    int maxSize;

public:
    ConnectionPool(int size) : maxSize(size) {
        for (int i = 0; i < size; ++i) {
            MYSQL* conn = mysql_init(NULL);
            mysql_real_connect(conn, "localhost", "root", "Stock1!2345", "emir_db", 3306, NULL, 0);
            pool.push(conn);
        }
    }

    ~ConnectionPool() {
        while (!pool.empty()) {
            mysql_close(pool.front());
            pool.pop();
        }
    }

    MYSQL* acquire() {
        std::unique_lock<std::mutex> lock(mtx);
        cv.wait(lock, [this]() { return !pool.empty(); });
        MYSQL* conn = pool.front();
        pool.pop();
        return conn;
    }

    void release(MYSQL* conn) {
        std::lock_guard<std::mutex> lock(mtx);
        pool.push(conn);
        cv.notify_one();
    }
};
