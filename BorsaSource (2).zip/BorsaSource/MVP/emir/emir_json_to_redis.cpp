#include <iostream>
#include <fstream>
#include <hiredis/hiredis.h>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

int main() {
    std::ifstream f("emirler.json");
    if (!f.is_open()) {
        std::cerr << "[HATA] Dosya açılamadı!\n";
        return 1;
    }

    json emirler;
    f >> emirler;

    redisContext* c = redisConnect("127.0.0.1", 6379);
    if (c == NULL || c->err) {
        std::cerr << "[REDIS] Bağlantı hatası\n";
        return 1;
    }

    for (const auto& emir : emirler) {
        int id = emir["id"];
        std::string key = "emir:" + std::to_string(id);
        std::string value = emir.dump();  // JSON objesini stringleştir
        redisCommand(c, "SET %s %s", key.c_str(), value.c_str());
        std::cout << "[REDIS] Kaydedildi: " << key << "\n";
    }

    redisFree(c);
    return 0;
}
