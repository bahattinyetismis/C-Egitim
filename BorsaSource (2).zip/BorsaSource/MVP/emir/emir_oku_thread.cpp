#include <iostream>
#include <string>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <C:/Program Files/MySQL/MySQL Server 8.0/include/mysql.h>

// Basit connection pool
class ConnectionPool {
private:
    std::queue<MYSQL*> pool;
    std::mutex mtx;
    std::condition_variable cv;
    int maxSize;

public:
    ConnectionPool(int size) : maxSize(size) {
        for (int i = 0; i < size; ++i) {
            MYSQL* conn = mysql_init(NULL);
            mysql_real_connect(conn, "localhost", "root", "Stock1!2345", "emir_db", 3306, NULL, 0);
            pool.push(conn);
        }
    }

    ~ConnectionPool() {
        while (!pool.empty()) {
            mysql_close(pool.front());
            pool.pop();
        }
    }

    MYSQL* acquire() {
        std::unique_lock<std::mutex> lock(mtx);
        cv.wait(lock, [this]() { return !pool.empty(); });
        MYSQL* conn = pool.front();
        pool.pop();
        return conn;
    }

    void release(MYSQL* conn) {
        std::lock_guard<std::mutex> lock(mtx);
        pool.push(conn);
        cv.notify_one();
    }

    int availableConnections() {
        std::lock_guard<std::mutex> lock(mtx);
        return static_cast<int>(pool.size());
    }
};

// Emir detayi çek
void readEmir(const std::string& kod, int threadId, ConnectionPool& pool, MYSQL*& connOut) {
    connOut = pool.acquire();

    std::cout << "[Thread " << threadId << "] '" << kod << "' kaydini okuyorum, baglantiyi aldim.\n";
    std::cout << "[Thread " << threadId << "] Pool'da kalan baglanti sayisi: " << pool.availableConnections() << "\n";

    std::string query = "SELECT * FROM emirler WHERE kod='" + kod + "' LIMIT 1";
    if (mysql_query(connOut, query.c_str()) == 0) {
        MYSQL_RES* res = mysql_store_result(connOut);
        if (res) {
            MYSQL_ROW row = mysql_fetch_row(res);
            if (row) {
                std::cout << "[Thread " << threadId << "] Emir detaylari:\n";
                MYSQL_FIELD* fields = mysql_fetch_fields(res);
                for (int i = 0; i < mysql_num_fields(res); ++i) {
                    std::cout << "  " << fields[i].name << ": " << (row[i] ? row[i] : "NULL") << "\n";
                }
            } else {
                std::cout << "[Thread " << threadId << "] Kayit bulunamadi.\n";
            }
            mysql_free_result(res);
        }
    } else {
        std::cerr << "[Thread " << threadId << "] Sorgu hatasi: " << mysql_error(connOut) << "\n";
    }

    // su anda connection release ETMİYORUZ — sonra yapilacak
}

int main() {
    ConnectionPool pool(5);
    std::cout << "[Main] Baslangiçta pool'daki baglanti sayisi: " << pool.availableConnections() << "\n";

    MYSQL* conn1 = nullptr;
    MYSQL* conn2 = nullptr;

    // Thread 1 - ASELS
    std::thread t1(readEmir, "ASELS", 1, std::ref(pool), std::ref(conn1));

    // Thread 2 - SISE
    std::thread t2(readEmir, "SISE", 2, std::ref(pool), std::ref(conn2));

    t1.join();
    t2.join();

    // simdi baglantilari release ediyoruz
    pool.release(conn1);
    std::cout << "[Thread 1] Connection release edildi.\n";
    pool.release(conn2);
    std::cout << "[Thread 2] Connection release edildi.\n";

    std::cout << "[Main] Son durumda pool'daki baglanti sayisi: " << pool.availableConnections() << "\n";
    return 0;
}
