// === emir_server.cpp ===
#include "include/httplib.h"              // cpp-httplib: HTTP sunucu/istemci için tek baslik dosyasi
#include "include/json.hpp"                // nlohmann/json: JSON ayristirma ve olusturma için tek baslik
#include "include/emir.hpp"               // Emir yapisi baslik dosyasi
#include <windows.h>              // Windows API: shared memory islemleri
#include <unordered_map>          // unordered_map: hisse bazli en son emir takibi için
#include <fstream>                // Dosyaya JSONL log yazmak için
#include <iostream>
#include <string>
#include <cstring>

using json = nlohmann::json;

const int MAX_EMIR = 1000; // Shared memory'e yazilabilecek maksimum emir sayisi
const char* SHM_NAME = "EMIR_SHM"; // Windows global shared memory adi

HANDLE hMapFile = nullptr;          // Shared memory handle
Emir* pSharedBuffer = nullptr;      // Shared memory'de emirler
int* pIndex = nullptr;              // Shared memory'de kaçinci emirdeyiz

// Son emirleri hizli erisim için tutan bellek içi harita (kod → Emir)
std::unordered_map<std::string, Emir> emirMap;

// Shared memory ilk kurulum fonksiyonu
void initSharedMemory() {
    size_t totalSize = sizeof(int) + MAX_EMIR * sizeof(Emir); // index + emir dizisi
    hMapFile = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, totalSize, SHM_NAME);

    if (!hMapFile) {
        std::cerr << "[HATA] Shared memory olusturulamadi\n";
        exit(1);
    }

    void* pBuf = MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, totalSize);
    if (!pBuf) {
        std::cerr << "[HATA] MapViewOfFile basarisiz\n";
        exit(1);
    }

    // İlk 4 bayt shared memory'de index tutulur, sonrasi Emir dizisidir
    pIndex = (int*)pBuf;
    pSharedBuffer = (Emir*)((char*)pBuf + sizeof(int));

    // Eğer baslangiç değeri geçersizse sifirla
    if (*pIndex < 0 || *pIndex > MAX_EMIR) *pIndex = 0;
}

int main() {
    initSharedMemory(); // shared memory baslat
    httplib::Server svr; // HTTP sunucu nesnesi

    // POST /api/istek endpoint'i: emir alir
    svr.Post("/api/istek", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            json j = json::parse(req.body); // Gelen JSON'i ayristir
            std::string kod = j.at("hisseKodu");
            double fiyat = j.at("fiyat");
            int adet = j.at("adet");
            std::string islem = j.value("islem", "BELIRSIZ");
            std::string kurum = j.value("araciKurum", "UNKNOWN");
            std::string zaman = j.value("zaman", "");

            // Shared memory kapasite kontrolü
            if (*pIndex >= MAX_EMIR) {
                res.status = 507;
                res.set_content("{\"error\":\"Shared memory dolu\"}", "application/json");
                return;
            }

            // Shared memory'ye yaz
            Emir& e = pSharedBuffer[(*pIndex)++];
            strncpy(e.kod, kod.c_str(), sizeof(e.kod));
            strncpy(e.islem, islem.c_str(), sizeof(e.islem));
            strncpy(e.kurum, kurum.c_str(), sizeof(e.kurum));
            strncpy(e.zaman, zaman.c_str(), sizeof(e.zaman));
            e.fiyat = fiyat;
            e.adet = adet;
            e.statu = 'G'; // Statü: Gerçeklesen olarak isaretle

            // Ayni zamanda bellekteki unordered_map'e de ekle/güncelle
            emirMap[kod] = e;

            // Log için JSON satiri hazirla
            json log = {
                {"kod", kod}, {"fiyat", fiyat}, {"adet", adet},
                {"islem", islem}, {"araciKurum", kurum}, {"zaman", zaman}, {"statu", "G"}
            };

            // Log dosyasina yaz (append)
            std::ofstream ofs("emirlog.jsonl", std::ios::app);
            ofs << log.dump() << "\n";

            std::cout << "[EMIR] Kaydedildi: " << log.dump() << "\n";
            res.set_content("{\"status\":\"OK\"}", "application/json");

        } catch (const std::exception& e) {
            res.status = 400;
            res.set_content(std::string("{\"error\":\"") + e.what() + "\"}", "application/json");
        }
    });

    std::cout << "[BASLAT] Sunucu http://localhost:8099 uzerinde calisiyor...\n";
    svr.listen("0.0.0.0", 8099); // Tüm arayüzlerde dinle
    return 0;
}