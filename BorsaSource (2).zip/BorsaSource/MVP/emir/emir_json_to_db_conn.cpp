// emir_json_to_mysql.cpp
#include <C:/Program Files/MySQL/MySQL Server 8.0/include/mysql.h>
#include <fstream>
#include <iostream>
#include <string>
#include <thread>
#include "include/json.hpp"
#include "connectionpool.h"

using json = nlohmann::json;

void insertToMySQL(const json& e, ConnectionPool& pool) {
    MYSQL* conn = pool.acquire();

    char query[512];
    snprintf(query, sizeof(query),
        "INSERT INTO emirler (kod, fiyat, adet, islem, kurum, zaman, statu) VALUES ('%s', %.2f, %d, '%s', '%s', '%s', '%c')",
        e["hisseKodu"].get<std::string>().c_str(),
        e["fiyat"].get<double>(),
        e["adet"].get<int>(),
        e.value("islem", "BELIRSIZ").c_str(),
        e.value("araciKurum", "UNKNOWN").c_str(),
        e.value("zaman", "").c_str(),
        'B');

    if (mysql_query(conn, query)) {
        std::cerr << "[MYSQL] INSERT hatası: " << mysql_error(conn) << "\n";
    }

    pool.release(conn);
}
int main() {
    std::ifstream f("emirler.json");
    if (!f.is_open()) {
        std::cerr << "[HATA] emirler.json dosyası açılamadı!\n";
        return 1;
    }

    json data;
    try {
        f >> data;
    } catch (const std::exception& e) {
        std::cerr << "[HATA] JSON parse hatası: " << e.what() << "\n";
        return 1;
    }

    if (!data.is_array()) {
        std::cerr << "[HATA] Beklenen JSON dizi formatı!\n";
        return 1;
    }

    ConnectionPool pool(5); // 5 bağlantılık havuz

    for (const auto& emir : data) {
        insertToMySQL(emir, pool);
    }

    std::cout << "[INFO] Tüm emirler veritabanına aktarıldı.\n";
    return 0;
}
