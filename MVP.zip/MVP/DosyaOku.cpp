// 📂 Gerekli başlık dosyaları
#include <iostream>
#include <fstream>      // std::ifstream
#include <sstream>      // std::stringstream
#include <string>
#include <mutex>
#include <stdexcept>

// 📒 Global mutex – dosya yazımı sırasında eşzamanlılık için
std::mutex hisseLogMutex;

// 🎯 Dosyaya yazma işlemini saran sınıf
class HisseLogger {
    std::ofstream file;

public:
    // 📂 Dosya açılır (ör: "hisse_log.txt")
    HisseLogger(const std::string& path) {
        file.open(path, std::ios::app);  // "append" modunda aç
        if (!file.is_open())
            throw std::runtime_error("Dosya açılamadı");
    }

    // 🔚 Otomatik dosya kapama
    ~HisseLogger() {
        if (file.is_open()) file.close();
    }

    // 🛑 Kopyalama yasak (aynı dosya birden fazla kez kapatılmasın diye)
    HisseLogger(const HisseLogger&) = delete;
    HisseLogger& operator=(const HisseLogger&) = delete;

    // ✅ Taşıma (move) serbest – sahipliği aktarır
    HisseLogger(HisseLogger&& other) noexcept : file(std::move(other.file)) {}
    HisseLogger& operator=(HisseLogger&& other) noexcept {
        if (this != &other) file = std::move(other.file);
        return *this;
    }

    // 🖊️ Dosyaya bir satır yazar
    void writeLine(const std::string& s) {
        file << s << '\n';
    }
};

// 🔒 Güvenli dosya yazımı yapan fonksiyon
void saveStockLog(const std::string& logLine) {
    std::lock_guard<std::mutex> lock(hisseLogMutex);  // 🔐 mutex kilitlenir
    HisseLogger logger("hisse_log.txt");              // 📂 dosya açılır
    logger.writeLine(logLine);                         // 🖊️ satır yazılır
} // 🔓 kilit ve dosya kapanır

// 📑 CSV dosyasını okuyup loglayan ana fonksiyon
void processCSV(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile.is_open()) {
        std::cerr << "CSV dosyası açılamadı: " << filePath << '\n';
        return;
    }

    std::string line;
    std::getline(inFile, line);  // ⚠️ Başlık satırını atla

    while (std::getline(inFile, line)) {
        std::stringstream ss(line);
        std::string kod, ad, fiyat, hacim, sektor;

        std::getline(ss, kod, ',');
        std::getline(ss, ad, ',');
        std::getline(ss, fiyat, ',');
        std::getline(ss, hacim, ',');
        std::getline(ss, sektor, ',');

        // 🏷️ Biçimli log satırı oluşturulur
        std::string logLine = kod + " | " + ad + " | " + fiyat + " TL | " + hacim + " adet | " + sektor;
        saveStockLog(logLine);  // 📝 satır log dosyasına yazılır
    }
}

// 🚀 Uygulama girişi
int main() {
    processCSV("C:/BorsaSource/MVP/BIST100_Verileri.csv");  // 📥 CSV okunur
    std::cout << "BIST100 log dosyasına aktarıldı.\n";
    return 0;
}
