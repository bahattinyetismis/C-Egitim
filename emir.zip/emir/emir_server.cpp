// === emir_server.cpp ===
#include "httplib.h"              // cpp-httplib: HTTP sunucu/istemci için tek başlık dosyası
#include "json.hpp"                // nlohmann/json: JSON ayrıştırma ve oluşturma için tek başlık
#include "emir.hpp"               // Emir yapısı başlık dosyası
#include <windows.h>              // Windows API: shared memory işlemleri
#include <unordered_map>          // unordered_map: hisse bazlı en son emir takibi için
#include <fstream>                // Dosyaya JSONL log yazmak için
#include <iostream>
#include <string>
#include <cstring>

using json = nlohmann::json;

const int MAX_EMIR = 1000; // Shared memory'e yazılabilecek maksimum emir sayısı
const char* SHM_NAME = "Global\\EMIR_SHM"; // Windows global shared memory adı

HANDLE hMapFile = nullptr;          // Shared memory handle
Emir* pSharedBuffer = nullptr;      // Shared memory'de emirler
int* pIndex = nullptr;              // Shared memory'de kaçıncı emirdeyiz

// Son emirleri hızlı erişim için tutan bellek içi harita (kod → Emir)
std::unordered_map<std::string, Emir> emirMap;

// Shared memory ilk kurulum fonksiyonu
void initSharedMemory() {
    size_t totalSize = sizeof(int) + MAX_EMIR * sizeof(Emir); // index + emir dizisi
    hMapFile = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, totalSize, SHM_NAME);

    if (!hMapFile) {
        std::cerr << "[HATA] Shared memory oluşturulamadı\n";
        exit(1);
    }

    void* pBuf = MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, totalSize);
    if (!pBuf) {
        std::cerr << "[HATA] MapViewOfFile başarısız\n";
        exit(1);
    }

    // İlk 4 bayt shared memory'de index tutulur, sonrası Emir dizisidir
    pIndex = (int*)pBuf;
    pSharedBuffer = (Emir*)((char*)pBuf + sizeof(int));

    // Eğer başlangıç değeri geçersizse sıfırla
    if (*pIndex < 0 || *pIndex > MAX_EMIR) *pIndex = 0;
}

int main() {
    initSharedMemory(); // shared memory başlat
    httplib::Server svr; // HTTP sunucu nesnesi

    // POST /api/istek endpoint'i: emir alır
    svr.Post("/api/istek", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            json j = json::parse(req.body); // Gelen JSON'ı ayrıştır
            std::string kod = j.at("hisseKodu");
            double fiyat = j.at("fiyat");
            int adet = j.at("adet");
            std::string islem = j.value("islem", "BELIRSIZ");
            std::string kurum = j.value("araciKurum", "UNKNOWN");
            std::string zaman = j.value("zaman", "");

            // Shared memory kapasite kontrolü
            if (*pIndex >= MAX_EMIR) {
                res.status = 507;
                res.set_content("{\"error\":\"Shared memory dolu\"}", "application/json");
                return;
            }

            // Shared memory'ye yaz
            Emir& e = pSharedBuffer[(*pIndex)++];
            strncpy(e.kod, kod.c_str(), sizeof(e.kod));
            strncpy(e.islem, islem.c_str(), sizeof(e.islem));
            strncpy(e.kurum, kurum.c_str(), sizeof(e.kurum));
            strncpy(e.zaman, zaman.c_str(), sizeof(e.zaman));
            e.fiyat = fiyat;
            e.adet = adet;
            e.statu = 'G'; // Statü: Gerçekleşen olarak işaretle

            // Aynı zamanda bellekteki unordered_map'e de ekle/güncelle
            emirMap[kod] = e;

            // Log için JSON satırı hazırla
            json log = {
                {"kod", kod}, {"fiyat", fiyat}, {"adet", adet},
                {"islem", islem}, {"araciKurum", kurum}, {"zaman", zaman}, {"statu", "G"}
            };

            // Log dosyasına yaz (append)
            std::ofstream ofs("emirlog.jsonl", std::ios::app);
            ofs << log.dump() << "\n";

            std::cout << "[EMIR] Kaydedildi: " << log.dump() << "\n";
            res.set_content("{\"status\":\"OK\"}", "application/json");

        } catch (const std::exception& e) {
            res.status = 400;
            res.set_content(std::string("{\"error\":\"") + e.what() + "\"}", "application/json");
        }
    });

    std::cout << "[BASLAT] Sunucu http://localhost:8099 üzerinde çalışıyor...\n";
    svr.listen("0.0.0.0", 8099); // Tüm arayüzlerde dinle
    return 0;
}