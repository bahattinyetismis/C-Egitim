#pragma once
// Bellekte sabit boyutlu olarak shared memory'de tutulacak emir yapısı
#pragma pack(push, 1) 
struct Emir {
    char kod[8];        // Hisse kodu (ör: AKBNK)
    double fiyat;       // Fiyat bilgisi
    int adet;           // Emir miktarı
    char islem[8];      // ALIS veya SATIS
    char kurum[32];     // Aracı kurum adı
    char zaman[32];     // Zaman bilgisi (ISO formatı önerilir)
    char statu;         // 'B': Bekleyen, 'G': Gerçekleşen
};
#pragma pack(pop)  // Pack(Push , ayarini geri al)