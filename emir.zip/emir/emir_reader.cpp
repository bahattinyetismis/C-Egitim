// === emir_reader.cpp ===
#include "emir.hpp"               // Emir yapısı tanımı (shared memory struct)
#include <windows.h>              // Windows API (shared memory işlemleri için)
#include <iostream>               // std::cin, std::cout
#include <iomanip>                // std::setw ile tablo hizalama
#include <vector>                 // std::vector: dinamik dizi
#include <algorithm>              // std::sort: sıralama işlemi
#include <string>                 // std::string: C++ string kullanımı

const int MAX_EMIR = 1000;                        // Maksimum emir kapasitesi
const char* SHM_NAME = "Global\\EMIR_SHM";        // Shared memory ismi (server ile aynı olmalı)

int main() {
    std::string basHarf, sonHarf;
    std::cout << "Kod aralığı girin (ör. A Z): ";
    std::cin >> basHarf >> sonHarf;

    // Girilen harfleri büyük harfe çevir (karşılaştırmalar için)
    std::transform(basHarf.begin(), basHarf.end(), basHarf.begin(), ::toupper);
    std::transform(sonHarf.begin(), sonHarf.end(), sonHarf.begin(), ::toupper);

    // Shared memory'e bağlan
    HANDLE hMapFile = OpenFileMappingA(FILE_MAP_READ, FALSE, SHM_NAME);
    if (!hMapFile) {
        std::cerr << "[HATA] Shared memory bulunamadı! Sunucu çalışıyor mu?\n";
        return 1;
    }

    // Paylaşılan bellek alanını map et
    size_t totalSize = sizeof(int) + MAX_EMIR * sizeof(Emir);
    void* pBuf = MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, totalSize);
    if (!pBuf) {
        std::cerr << "[HATA] MapViewOfFile başarısız\n";
        return 1;
    }

    // Shared memory yapısına erişim: ilk 4 byte index (kaç emir var), sonrası emirler
    int* pIndex = (int*)pBuf;
    Emir* emirler = (Emir*)((char*)pBuf + sizeof(int));

    std::vector<Emir> secilenler; // Ekran aralığına giren emirleri burada topla

    // Bellekteki tüm emirleri kontrol et
    for (int i = 0; i < *pIndex; ++i) {
        std::string kod(emirler[i].kod);
        // Kod boş değilse ve girilen harf aralığındaysa listeye ekle
        if (!kod.empty() && kod >= basHarf && kod <= sonHarf) {
            secilenler.push_back(emirler[i]);
        }
    }

    // Kodlara göre alfabetik sıralama (std::sort + lambda fonksiyonu)
    std::sort(secilenler.begin(), secilenler.end(), [](const Emir& a, const Emir& b) {
        return std::string(a.kod) < std::string(b.kod);
    });

    std::cout << "\n[INFO] Filtrelenmiş ve sıralanmış " << secilenler.size() << " emir:\n\n";

    // Tablo başlıklarını yaz (hizalanmış şekilde)
    std::cout << std::left
              << std::setw(8) << "Kod"
              << std::setw(10) << "Fiyat"
              << std::setw(8) << "Adet"
              << std::setw(10) << "Islem"
              << std::setw(16) << "Kurum"
              << std::setw(22) << "Zaman"
              << std::setw(6) << "Statu" << "\n";
    std::cout << std::string(80, '-') << "\n";

    // Seçilen ve sıralanan emirleri tablo halinde yaz
    for (const Emir& e : secilenler) {
        std::cout << std::left
                  << std::setw(8) << e.kod
                  << std::setw(10) << e.fiyat
                  << std::setw(8) << e.adet
                  << std::setw(10) << e.islem
                  << std::setw(16) << e.kurum
                  << std::setw(22) << e.zaman
                  << std::setw(6) << e.statu << "\n";
    }

    // Shared memory bağlantısını kapat
    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);
    return 0;
}