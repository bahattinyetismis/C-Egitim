#include <iostream>

void degistir(int& r) { // r, orijinal degiskenin takma adi
    r += 10; // Orijinal degiskenin degeri 10 artirilir
}

int main() {
    int sayi = 5;
    std::cout << "Fonksiyon cagrilmadan once: " << sayi << std::endl; // Cikti: 5

    degistir(sayi); // sayi değişkenini degistir fonksiyonuna referans olarak gonderiyoruz

    std::cout << "Fonksiyon cagrildiktan sonra: " << sayi << std::endl; // Cikti: 15
    return 0;
}