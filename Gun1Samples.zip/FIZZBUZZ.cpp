#include <iostream>
#include <vector>
#include <string>

std::string tag(int n) {
    if (n%15==0) return "FizzBuzz";
    if (n%3 ==0) return "Fizz";
    if (n%5 ==0) return "Buzz";
    return std::to_string(n);
}

int main() {
    const int MAX = 30;
    std::vector<std::string> dizi;
    dizi.reserve(MAX);

    for (int i=1;i<=MAX;++i)          // klasik for
        dizi.push_back(tag(i));

    // range-based, const referansla yazdır
    for (const auto& s : dizi) std::cout << s << '\n';
}
