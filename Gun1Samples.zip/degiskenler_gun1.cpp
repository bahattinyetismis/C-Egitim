#include <iostream>
#include <memory>
#include <vector>

constexpr size_t MAX {5};

int main() {
    std::vector<int> sayilar;
    sayilar.reserve(MAX);

    for (auto i{0u}; i < MAX; ++i) {
        sayilar.push_back(static_cast<int>(i * i));
    }

    std::unique_ptr<int[]> kareler = std::make_unique<int[]>(MAX);
    for (size_t i{}; i < MAX; ++i) kareler[i] = sayilar[i];

    // sayilar vektörünü ekrana yazdır
    std::cout << "sayilar = {";
    for (size_t i = 0; i < MAX; ++i) {
        std::cout << sayilar[i];
        if (i != MAX - 1) std::cout << ", ";
    }
    std::cout << "}\n";

    // kareler dizisini ekrana yazdır
    std::cout << "Döngü sonunda:" << std::endl;
    for (size_t i = 0; i < MAX; ++i) {
        std::cout << "kareler[" << i << "] = " << kareler[i] << std::endl;
    }
}

